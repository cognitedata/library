import type { CogniteClient } from "@cognite/sdk";
import { LRUCache } from "lru-cache";
import { isAppCachingEnabled } from "@/shared/app-caching-flag";

export type TransformationByIdsRow = {
  id?: number | string;
  name?: string;
  query?: string;
  destination?: {
    view?: { space?: string; externalId?: string; version?: string };
    dataModel?: {
      space?: string;
      externalId?: string;
      version?: string;
      destinationType?: string;
    };
  };
};

export type TransformationCacheStatRow = {
  id: string;
  label: string;
  size: number;
  max: number;
  fillRate: number;
  ttlMs: number;
  calculatedSize: number;
  maxSize: number;
};

type TxGetSdk = Pick<CogniteClient, "project" | "get">;
type TxPostSdk = Pick<CogniteClient, "project" | "post">;

function stableParamKey(params: Record<string, string>): string {
  const keys = Object.keys(params).sort();
  return keys.map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k] ?? "")}`).join("&");
}

function rowKey(project: string, id: string): string {
  return `${project}\x1f${id}`;
}

export const TX_LIST_CACHE_MAX = 80;
export const TX_LIST_CACHE_TTL_MS = 60 * 60 * 1000;
const listCache = new LRUCache<string, Record<string, unknown>>({
  max: TX_LIST_CACHE_MAX,
  ttl: TX_LIST_CACHE_TTL_MS,
});
const listInFlight = new Map<string, Promise<unknown>>();

export const TX_JOBS_CACHE_MAX = 3000;
export const TX_JOBS_CACHE_TTL_MS = 60 * 60 * 1000;
const jobsCache = new LRUCache<string, Record<string, unknown>>({
  max: TX_JOBS_CACHE_MAX,
  ttl: TX_JOBS_CACHE_TTL_MS,
});
const jobsInFlight = new Map<string, Promise<unknown>>();

export const TX_JOB_METRICS_CACHE_MAX = 4000;
export const TX_JOB_METRICS_CACHE_TTL_MS = 60 * 60 * 1000;
const jobMetricsCache = new LRUCache<string, Record<string, unknown>>({
  max: TX_JOB_METRICS_CACHE_MAX,
  ttl: TX_JOB_METRICS_CACHE_TTL_MS,
});
const jobMetricsInFlight = new Map<string, Promise<unknown>>();

export const TX_BY_ID_ROW_CACHE_MAX = 8000;
export const TX_BY_ID_ROW_CACHE_TTL_MS = 60 * 60 * 1000;
const byIdRowCache = new LRUCache<string, TransformationByIdsRow>({
  max: TX_BY_ID_ROW_CACHE_MAX,
  ttl: TX_BY_ID_ROW_CACHE_TTL_MS,
});

export async function cachedTransformationsList(
  sdk: TxGetSdk,
  params: Record<string, string>
): Promise<unknown> {
  if (!isAppCachingEnabled()) {
    return sdk.get(`/api/v1/projects/${sdk.project}/transformations`, { params });
  }
  const key = `${sdk.project}:txList:${stableParamKey(params)}`;
  const hit = listCache.get(key);
  if (hit) return hit;
  const inFlight = listInFlight.get(key);
  if (inFlight) return inFlight;
  const request = sdk
    .get(`/api/v1/projects/${sdk.project}/transformations`, { params })
    .then((response) => {
      listCache.set(key, response as unknown as Record<string, unknown>);
      return response;
    })
    .finally(() => {
      listInFlight.delete(key);
    });
  listInFlight.set(key, request);
  return request;
}

export async function cachedTransformationJobs(
  sdk: TxGetSdk,
  transformationId: string,
  limit: string,
  cursor?: string
): Promise<unknown> {
  if (!isAppCachingEnabled()) {
    return sdk.get(`/api/v1/projects/${sdk.project}/transformations/jobs`, {
      params: { limit, transformationId, ...(cursor ? { cursor } : {}) },
    });
  }
  const key = `${sdk.project}:txJobs:${transformationId}:${limit}:${cursor ?? ""}`;
  const hit = jobsCache.get(key);
  if (hit) return hit;
  const inFlight = jobsInFlight.get(key);
  if (inFlight) return inFlight;
  const request = sdk
    .get(`/api/v1/projects/${sdk.project}/transformations/jobs`, {
      params: { limit, transformationId, ...(cursor ? { cursor } : {}) },
    })
    .then((response) => {
      jobsCache.set(key, response as unknown as Record<string, unknown>);
      return response;
    })
    .finally(() => {
      jobsInFlight.delete(key);
    });
  jobsInFlight.set(key, request);
  return request;
}

export async function cachedTransformationJobMetrics(
  sdk: TxGetSdk,
  jobId: string
): Promise<unknown> {
  if (!isAppCachingEnabled()) {
    return sdk.get(
      `/api/v1/projects/${sdk.project}/transformations/jobs/${jobId}/metrics`
    );
  }
  const key = `${sdk.project}:txJobMetrics:${jobId}`;
  const hit = jobMetricsCache.get(key);
  if (hit) return hit;
  const inFlight = jobMetricsInFlight.get(key);
  if (inFlight) return inFlight;
  const request = sdk
    .get(`/api/v1/projects/${sdk.project}/transformations/jobs/${jobId}/metrics`)
    .then((response) => {
      jobMetricsCache.set(key, response as unknown as Record<string, unknown>);
      return response;
    })
    .finally(() => {
      jobMetricsInFlight.delete(key);
    });
  jobMetricsInFlight.set(key, request);
  return request;
}

export const TRANSFORMATIONS_BY_IDS_BATCH_SIZE = 100;

export type TransformationsByIdsProgress = {
  fetched: number;
  total: number;
  batchIndex: number;
  batchTotal: number;
};

function buildByIdsPayload(ids: string[]): Array<{ id: number } | { id: string }> {
  const items: Array<{ id: number } | { id: string }> = [];
  for (const raw of ids) {
    if (!raw) continue;
    const n = Number(raw);
    if (Number.isFinite(n) && String(n) === raw) items.push({ id: n });
    else items.push({ id: raw });
  }
  return items;
}

export async function fetchTransformationsByIds(
  sdk: TxPostSdk,
  project: string,
  ids: string[],
  opts?: { onProgress?: (progress: TransformationsByIdsProgress) => void }
): Promise<Map<string, TransformationByIdsRow>> {
  const onProgress = opts?.onProgress;
  const out = new Map<string, TransformationByIdsRow>();
  const unique = [...new Set(ids.filter(Boolean))];
  const missing: string[] = [];
  const useCache = isAppCachingEnabled();
  for (const id of unique) {
    const k = rowKey(project, id);
    const row = useCache ? byIdRowCache.get(k) : undefined;
    if (row) out.set(id, row);
    else missing.push(id);
  }

  const batchTotal = Math.max(1, Math.ceil(missing.length / TRANSFORMATIONS_BY_IDS_BATCH_SIZE));
  if (missing.length === 0) {
    onProgress?.({ fetched: unique.length, total: 0, batchIndex: 0, batchTotal: 0 });
    return out;
  }

  for (let i = 0; i < missing.length; i += TRANSFORMATIONS_BY_IDS_BATCH_SIZE) {
    const batchIndex = Math.floor(i / TRANSFORMATIONS_BY_IDS_BATCH_SIZE) + 1;
    const chunk = missing.slice(i, i + TRANSFORMATIONS_BY_IDS_BATCH_SIZE);
    const items = buildByIdsPayload(chunk);
    if (items.length === 0) continue;
    const cacheRowsFromResponse = useCache && items.length === 1;
    try {
      const response = (await sdk.post(
        `/api/v1/projects/${project}/transformations/byids`,
        { data: { items } }
      )) as { data?: { items?: TransformationByIdsRow[] } };
      for (const row of response.data?.items ?? []) {
        if (row.id == null) continue;
        const idStr = String(row.id);
        if (cacheRowsFromResponse) {
          byIdRowCache.set(rowKey(project, idStr), row);
        }
        out.set(idStr, row);
      }
    } catch {
      /* skip batch */
    }
    onProgress?.({
      fetched: out.size,
      total: unique.length,
      batchIndex,
      batchTotal,
    });
  }
  return out;
}

export function getTransformationsListCacheStats(): TransformationCacheStatRow {
  return {
    id: "transformations.list",
    label: "Transformations list (GET)",
    size: listCache.size,
    max: listCache.max,
    fillRate: listCache.max > 0 ? listCache.size / listCache.max : 0,
    ttlMs: TX_LIST_CACHE_TTL_MS,
    calculatedSize: listCache.calculatedSize ?? 0,
    maxSize: listCache.maxSize ?? listCache.max,
  };
}

export function getTransformationJobsCacheStats(): TransformationCacheStatRow {
  return {
    id: "transformations.jobs",
    label: "Transformation jobs (GET)",
    size: jobsCache.size,
    max: jobsCache.max,
    fillRate: jobsCache.max > 0 ? jobsCache.size / jobsCache.max : 0,
    ttlMs: TX_JOBS_CACHE_TTL_MS,
    calculatedSize: jobsCache.calculatedSize ?? 0,
    maxSize: jobsCache.maxSize ?? jobsCache.max,
  };
}

export function getTransformationJobMetricsCacheStats(): TransformationCacheStatRow {
  return {
    id: "transformations.jobMetrics",
    label: "Transformation job metrics (GET)",
    size: jobMetricsCache.size,
    max: jobMetricsCache.max,
    fillRate: jobMetricsCache.max > 0 ? jobMetricsCache.size / jobMetricsCache.max : 0,
    ttlMs: TX_JOB_METRICS_CACHE_TTL_MS,
    calculatedSize: jobMetricsCache.calculatedSize ?? 0,
    maxSize: jobMetricsCache.maxSize ?? jobMetricsCache.max,
  };
}

export function getTransformationByIdRowCacheStats(): TransformationCacheStatRow {
  return {
    id: "transformations.byIdRows",
    label: "Transformation by-id rows (POST byids; LRU only for single-id calls)",
    size: byIdRowCache.size,
    max: byIdRowCache.max,
    fillRate: byIdRowCache.max > 0 ? byIdRowCache.size / byIdRowCache.max : 0,
    ttlMs: TX_BY_ID_ROW_CACHE_TTL_MS,
    calculatedSize: byIdRowCache.calculatedSize ?? 0,
    maxSize: byIdRowCache.maxSize ?? byIdRowCache.max,
  };
}
