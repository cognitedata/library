# SourceSystem Package

This package contains SourceSystem modules, which are pipelines that can be used to ingest data
from external systems into CDF.
