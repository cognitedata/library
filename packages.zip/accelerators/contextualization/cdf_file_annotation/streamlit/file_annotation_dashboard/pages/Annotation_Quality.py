import altair as alt
import pandas as pd
import streamlit as st
from cognite.client.data_classes.data_modeling import NodeId
from helper import (
    build_potential_status_map,
    build_unmatched_tags_with_regions,
    derive_annotation_status,
    fetch_annotation_states,
    fetch_extraction_pipeline_config,
    fetch_manual_patterns,
    fetch_pattern_catalog,
    fetch_raw_table_data,
    find_pipelines,
    generate_file_canvas,
    normalize,
    save_manual_patterns,
    show_connect_unmatched_ui,
)

# --- Page Configuration ---
st.set_page_config(
    page_title="Annotation Quality",
    page_icon="🎯",
    layout="wide",
)


# --- Callback function to reset selection ---
def reset_selection():
    st.session_state.selected_row_index = None


# --- Initialize Session State ---
if "selected_row_index" not in st.session_state:
    st.session_state.selected_row_index = None
if "selected_unmatched_per_file_index" not in st.session_state:
    st.session_state.selected_unmatched_per_file_index = None
if "selected_unmatched_overall_index" not in st.session_state:
    st.session_state.selected_unmatched_overall_index = None
if "selected_entity_to_connect_index" not in st.session_state:
    st.session_state.selected_entity_to_connect_index = None
if "selected_entity_type_to_connect" not in st.session_state:
    st.session_state.selected_entity_type_to_connect = None

# --- Sidebar for Pipeline Selection ---
st.sidebar.title("Pipeline Selection")
pipeline_ids = find_pipelines()

if not pipeline_ids:
    st.info("No active file annotation pipelines found to monitor.")
    st.stop()

selected_pipeline = st.sidebar.selectbox("Select a pipeline:", options=pipeline_ids, key="quality_pipeline_selector")

# --- Data Fetching & Processing ---
config_result = fetch_extraction_pipeline_config(selected_pipeline)
if not config_result:
    st.error(f"Could not fetch configuration for pipeline: {selected_pipeline}")
    st.stop()

ep_config, view_config = config_result

annotation_state_view = view_config["annotation_state"]
file_view = view_config["file"]
target_entities_view = view_config["target_entities"]

apply_config = ep_config.get("finalizeFunction", {}).get("applyService", {})
secondary_scope_property = ep_config.get("launchFunction", {}).get("secondaryScopeProperty")
cache_config = ep_config.get("launchFunction", {}).get("cacheService", {})
db_name = apply_config.get("rawDb")
pattern_table = apply_config.get("rawTableDocPattern")
tag_table = apply_config.get("rawTableDocTag")
doc_table = apply_config.get("rawTableDocDoc")
cache_table = cache_config.get("rawTableCache")
manual_patterns_table = cache_config.get("rawManualPatternsCatalog")
file_resource_property = ep_config.get("launchFunction", {}).get("fileResourceProperty", "")
target_entities_resource_property = ep_config.get("launchFunction", {}).get("targetEntitiesResourceProperty", "")

if not all([db_name, pattern_table, tag_table, doc_table, cache_table, manual_patterns_table]):
    st.error("Could not find all required RAW table names in the pipeline configuration.")
    st.stop()

# --- Main Application ---
st.title("Annotation Quality Dashboard")

# --- Create Tabs ---
overall_tab, per_file_tab, management_tab = st.tabs(
    ["Overall Quality Metrics", "Per-File Analysis", "Pattern Management"]
)

# ==========================================
#         OVERALL QUALITY METRICS TAB
# ==========================================
with overall_tab:
    df_patterns = fetch_raw_table_data(db_name, pattern_table)
    df_tags = fetch_raw_table_data(db_name, tag_table)
    df_docs = fetch_raw_table_data(db_name, doc_table)

    if df_patterns.empty:
        st.info("The pattern catalog is empty. Run the pipeline with patternMode enabled to generate data.")
    else:
        df_annotations = pd.concat([df_tags, df_docs], ignore_index=True)

        st.subheader(
            "Overall Annotation Quality",
            help="Provides a high-level summary of pattern performance across all files. Use these aggregate metrics, charts, and tag lists to understand the big picture and identify systemic trends or gaps in the pattern catalog.",
        )
        df_file_meta = fetch_annotation_states(annotation_state_view, file_view)

        metadata_props = sorted([c for c in df_file_meta.columns]) if not df_file_meta.empty else []

        selected_metadata_prop = "None"
        selected_metadata_values = []
        selected_file_ids = None

        with st.expander("Filter Quality Table"):
            filter_col1, filter_col2 = st.columns(2)
            with filter_col1:
                selected_metadata_prop = st.selectbox(
                    "Select Metadata Property",
                    options=["None"] + metadata_props,
                    on_change=reset_selection,
                    key="overall_metadata_property",
                )

            if selected_metadata_prop != "None" and not df_file_meta.empty:
                unique_values = sorted(df_file_meta[selected_metadata_prop].dropna().unique().tolist())
                with filter_col2:
                    selected_metadata_values = st.multiselect(
                        f"Select Value(s) for {selected_metadata_prop}", options=unique_values, on_change=reset_selection
                    )
                if selected_metadata_values:
                    selected_file_ids = set(
                        df_file_meta[df_file_meta[selected_metadata_prop].isin(selected_metadata_values)]["fileExternalId"].tolist()
                    )

        if selected_file_ids:
            df_metrics_input = df_patterns[df_patterns["startNode"].isin(selected_file_ids)]
            if not df_annotations.empty and "startNode" in df_annotations.columns:
                df_annotations_input = df_annotations[df_annotations["startNode"].isin(selected_file_ids)]
            else:
                df_annotations_input = pd.DataFrame()
        else:
            df_metrics_input = df_patterns
            df_annotations_input = df_annotations

        all_resource_types = ["All"] + sorted(df_metrics_input["endNodeResourceType"].dropna().unique().tolist())

        df_metrics_input = df_metrics_input.copy()

        df_potential_sources = df_metrics_input[df_metrics_input["status"].isin(["Suggested", "Rejected"]) ]
        potential_tags_original = set(df_potential_sources["startNodeText"].dropna())

        annotations_from_tables = set(df_annotations_input["startNodeText"]) if not df_annotations_input.empty and "startNodeText" in df_annotations_input.columns else set()
        approved_from_patterns = set(df_metrics_input[df_metrics_input["status"] == "Approved"]["startNodeText"].dropna())

        actual_annotations_original = annotations_from_tables.union(approved_from_patterns)

        text_map = {
            normalize(text): text for text in potential_tags_original.union(actual_annotations_original) if text
        }

        normalized_potential_set = {normalize(t) for t in potential_tags_original}
        normalized_actual_set = {normalize(t) for t in actual_annotations_original}

        normalized_unmatched = normalized_potential_set - normalized_actual_set

        actual_annotations_set = {text_map[t] for t in normalized_actual_set if t in text_map}
        potential_new_annotations_set = {text_map[t] for t in normalized_unmatched if t in text_map}

        total_actual = len(actual_annotations_set)
        total_potential = len(potential_new_annotations_set)

        overall_coverage = (
            (total_actual / (total_actual + total_potential)) * 100 if (total_actual + total_potential) > 0 else 0
        )

        st.metric(
            "Overall Annotation Coverage",
            f"{overall_coverage:.2f}%",
            help="The percentage of all unique tags (both actual and potential) that have been successfully annotated. Formula: Total Actual Annotations / (Total Actual Annotations + Total Potential New Annotations)",
        )

        st.divider()
        chart_data = []
        for resource_type in all_resource_types[1:]:
            df_patterns_filtered = df_metrics_input[df_metrics_input["endNodeResourceType"] == resource_type]
            df_patterns_candidate_rt = df_patterns_filtered[df_patterns_filtered["status"].isin(["Suggested", "Rejected"])]
            df_patterns_approved_rt = df_patterns_filtered[df_patterns_filtered["status"] == "Approved"]

            df_annotations_filtered = (
                df_annotations_input[df_annotations_input["endNodeResourceType"] == resource_type]
                if not df_annotations_input.empty and "endNodeResourceType" in df_annotations_input.columns
                else pd.DataFrame()
            )

            candidate_set = set(df_patterns_candidate_rt["startNodeText"].dropna())
            actual = (
                set(df_annotations_filtered["startNodeText"])
                if not df_annotations_filtered.empty and "startNodeText" in df_annotations_filtered.columns
                else set()
            )
            actual = actual.union(set(df_patterns_approved_rt["startNodeText"].dropna()) if not df_patterns_approved_rt.empty else set())
            norm_potential = {normalize(p) for p in candidate_set}
            norm_actual = {normalize(a) for a in actual}

            total_actual_rt = len(norm_actual)
            total_potential_rt = len(norm_potential - norm_actual)

            coverage = (
                (total_actual_rt / (total_actual_rt + total_potential_rt)) * 100
                if (total_actual_rt + total_potential_rt) > 0
                else 0
            )
            chart_data.append(
                {
                    "resourceType": resource_type,
                    "coverageRate": coverage,
                    "actualAnnotations": total_actual_rt,
                    "potentialNewAnnotations": total_potential_rt,
                }
            )

        df_chart_data = pd.DataFrame(chart_data)
        df_chart_display = df_chart_data

        if not df_chart_display.empty:
            coverage_chart = (
                alt.Chart(df_chart_display)
                .mark_bar()
                .encode(
                    x=alt.X("resourceType:N", title="Resource Type", sort="-y"),
                    y=alt.Y("coverageRate:Q", title="Annotation Coverage (%)", scale=alt.Scale(domain=[0, 100])),
                    tooltip=["resourceType", "coverageRate", "actualAnnotations", "potentialNewAnnotations"],
                )
                .properties(title="Annotation Coverage by Resource Type")
            )
            st.altair_chart(coverage_chart, use_container_width=True)

        else:
            st.info("No data available for the selected resource type to generate charts.")

        st.divider()
        # --- Pattern Catalog ---
        with st.expander("View Full Pattern Catalog"):
            df_auto_patterns = fetch_pattern_catalog(db_name, cache_table)
            df_manual_patterns = fetch_manual_patterns(db_name, manual_patterns_table)

            df_auto_patterns.rename(columns={"resourceType": "resource_type", "pattern": "sample"}, inplace=True)
            df_combined_patterns = (
                pd.concat(
                    [df_auto_patterns[["resource_type", "sample"]], df_manual_patterns[["resource_type", "sample"]]]
                )
                .drop_duplicates()
                .sort_values(by=["resource_type", "sample"])
            )

            if df_combined_patterns.empty:
                st.info("Pattern catalog is empty or could not be loaded.")
            else:
                resource_types = sorted(df_combined_patterns["resource_type"].unique())
                tabs = st.tabs(resource_types)
                for i, resource_type in enumerate(resource_types):
                    with tabs[i]:
                        df_filtered_patterns = df_combined_patterns[
                            df_combined_patterns["resource_type"] == resource_type
                        ]
                        st.dataframe(
                            df_filtered_patterns[["sample"]],
                            use_container_width=True,
                            hide_index=True,
                            column_config={"sample": "Pattern"},
                        )
        tag_col1, tag_col2 = st.columns(2)
        with tag_col1:
            st.metric(
                "✅ Actual Annotations",
                f"{total_actual}",
                help="A list of all unique tags that have been successfully created. This is our ground truth.",
            )
            actual_status_map = {}
            df_approved_rows = df_metrics_input[df_metrics_input["status"] == "Approved"]
            if not df_approved_rows.empty:
                for _, r in df_approved_rows.iterrows():
                    text = r.get("startNodeText")
                    if not text:
                        continue
                    actual_status_map.setdefault(
                        text,
                        derive_annotation_status(r.get("tags"), row_status=r.get("status")),
                    )
            for text in annotations_from_tables:
                actual_status_map.setdefault(text, "Regularly Annotated")

            actual_rows = [(t, actual_status_map.get(t, "Regularly Annotated")) for t in sorted(list(actual_annotations_set))]
            st.dataframe(
                pd.DataFrame(actual_rows, columns=["Tag", "Status"]),
                use_container_width=True,
                hide_index=True,
            )
        with tag_col2:
            st.metric(
                "💡 Potential New Annotations",
                f"{total_potential}",
                help="A list of all unique tags found by the pattern-mode job that do not yet exist as actual annotations. This is now a clean 'to-do list' of tags that could be promoted or used to create new patterns.",
            )

            unmatched_display = pd.DataFrame(sorted(list(potential_new_annotations_set)), columns=["text"])
            unmatched_display.insert(0, "Select", False)

            if st.session_state.selected_unmatched_overall_index is not None:
                idx = st.session_state.selected_unmatched_overall_index

                if idx in unmatched_display.index:
                    unmatched_display.loc[:, "Select"] = False
                    unmatched_display.at[idx, "Select"] = True

            unmatched_tags_list = list(potential_new_annotations_set)
            df_unmatched_filtered = df_metrics_input[df_metrics_input["startNodeText"].isin(unmatched_tags_list)]

            tag_to_files_unmatched = (
                df_unmatched_filtered.groupby("startNodeText")["startNode"].unique().apply(list).to_dict()
            )

            potential_status_map = build_potential_status_map(df_potential_sources) if "tags" in df_potential_sources.columns else {}

            unmatched_display["Status"] = unmatched_display["text"].apply(lambda t: potential_status_map.get(t, "Suggested"))

            tag_occurrences = (
                df_unmatched_filtered.groupby("startNodeText")["startNode"]
                .count()
                .reset_index()
                .rename(columns={"startNode": "occurrenceCount"})
            )

            tag_file_counts = (
                df_unmatched_filtered.groupby("startNodeText")["startNode"]
                .nunique()
                .reset_index()
                .rename(columns={"startNode": "fileCount"})
            )

            tag_stats = tag_file_counts.merge(tag_occurrences, on="startNodeText", how="outer")

            unmatched_display = unmatched_display.merge(tag_stats, left_on="text", right_on="startNodeText", how="left")
            unmatched_display.drop(columns=["startNodeText"], inplace=True)

            unmatched_editor_key = "overall_unmatched_tags_editor"
            unmatched_data_editor = st.data_editor(
                unmatched_display,
                key=unmatched_editor_key,
                column_config={
                    "Select": st.column_config.CheckboxColumn(required=True),
                    "text": "Tag",
                    "fileCount": "Associated Files",
                    "occurrenceCount": "Occurrences",
                    "Status": "Status",
                },
                use_container_width=True,
                hide_index=True,
                disabled=unmatched_display.columns.difference(["Select"]),
            )

            selected_indices = unmatched_data_editor[unmatched_data_editor.Select].index.tolist()

            if len(selected_indices) > 1:
                new_selection = [
                    idx for idx in selected_indices if idx != st.session_state.selected_unmatched_overall_index
                ]
                st.session_state.selected_unmatched_overall_index = new_selection[0] if new_selection else None
                st.rerun()
            elif len(selected_indices) == 1:
                st.session_state.selected_unmatched_overall_index = selected_indices[0]
            elif len(selected_indices) == 0 and st.session_state.selected_unmatched_overall_index is not None:
                st.session_state.selected_unmatched_overall_index = None
                st.rerun()

        if st.session_state.selected_unmatched_overall_index is not None:
            selected_tag_row = unmatched_display.loc[st.session_state.selected_unmatched_overall_index]
            selected_tag_text = selected_tag_row["text"]
            
            associated_files = tag_to_files_unmatched.get(selected_tag_text, [])

            show_connect_unmatched_ui(
                selected_tag_text,
                file_view,
                target_entities_view,
                file_resource_property,
                target_entities_resource_property,
                associated_files=associated_files,
                tab="overall",
                db_name=db_name,
                pattern_table=pattern_table,
                apply_config=apply_config,
                annotation_state_view=annotation_state_view,
                secondary_scope_prop=secondary_scope_property,
            )


# ==========================================
#           PER-FILE ANALYSIS TAB
# ==========================================
with per_file_tab:
    st.subheader(
        "Per-File Annotation Quality",
        help="A deep-dive tool for investigating the quality scores of individual files. Filter the table to find specific examples of high or low performance, then select a file to see a detailed breakdown of its specific matched, unmatched, and missed tags.",
    )

    df_patterns_file = fetch_raw_table_data(db_name, pattern_table)
    df_tags_file = fetch_raw_table_data(db_name, tag_table)
    df_docs_file = fetch_raw_table_data(db_name, doc_table)

    if df_patterns_file.empty:
        st.info("The pattern catalog is empty. Run the pipeline with patternMode enabled to generate data.")
    else:
        df_annotations_file = pd.concat([df_tags_file, df_docs_file], ignore_index=True)

        df_patterns_file = df_patterns_file.copy()

        df_patterns_agg_all = df_patterns_file.groupby("startNode")["startNodeText"].apply(set).reset_index(name="allPatterns")

        potential_rows = df_patterns_file[df_patterns_file["status"].isin(["Suggested", "Reproved", "Rejected"]) ]
        if potential_rows.empty:
            df_patterns_agg_file = pd.DataFrame(columns=["startNode", "potentialTags"])
        else:
            df_patterns_agg_file = potential_rows.groupby("startNode")["startNodeText"].apply(set).reset_index(name="potentialTags")

        df_annotations_agg_file = df_annotations_file.groupby("startNode")["startNodeText"].apply(set).reset_index(name="actualAnnotations") if not df_annotations_file.empty else pd.DataFrame(columns=["startNode", "actualAnnotations"])

        approved_rows = df_patterns_file[df_patterns_file["status"] == "Approved"]
        df_approved_agg = (
            approved_rows.groupby("startNode")["startNodeText"].apply(set).reset_index(name="approvedPatterns")
            if not approved_rows.empty
            else pd.DataFrame(columns=["startNode", "approvedPatterns"])
        )

        df_quality_file = pd.merge(df_patterns_agg_all, df_annotations_agg_file, on="startNode", how="left")
        df_quality_file = pd.merge(df_quality_file, df_approved_agg, on="startNode", how="left")
        df_quality_file = pd.merge(df_quality_file, df_patterns_agg_file, on="startNode", how="left")
        df_quality_file["actualAnnotations"] = df_quality_file["actualAnnotations"].apply(
            lambda x: x if isinstance(x, set) else set()
        )
        df_quality_file["approvedPatterns"] = df_quality_file["approvedPatterns"].apply(
            lambda x: x if isinstance(x, set) else set()
        )
        df_quality_file["actualAnnotations"] = df_quality_file.apply(
            lambda r: r["actualAnnotations"].union(r["approvedPatterns"]) if isinstance(r["actualAnnotations"], set) else r["approvedPatterns"],
            axis=1,
        )

        def calculate_metrics(row):
            potential = row.get("potentialTags")

            if isinstance(potential, float) and pd.isna(potential):
                potential_set = set()
            elif isinstance(potential, (set, list, tuple)):
                potential_set = set(potential)
            elif potential is None:
                potential_set = set()
            else:
                potential_set = {potential}

            actual = row.get("actualAnnotations")
            if isinstance(actual, float) and pd.isna(actual):
                actual_set = set()
            elif isinstance(actual, (set, list, tuple)):
                actual_set = set(actual)
            elif actual is None:
                actual_set = set()
            else:
                actual_set = {actual}

            norm_potential = {normalize(str(p)) for p in potential_set if p is not None}
            norm_actual = {normalize(str(a)) for a in actual_set if a is not None}

            total_actual_pf = len(norm_actual)
            total_potential_pf = len(norm_potential - norm_actual)

            return total_actual_pf, total_potential_pf

        if df_quality_file.empty:
            df_quality_file["actualAnnotationsCount"] = pd.Series(dtype="int")
            df_quality_file["potentialNewAnnotationsCount"] = pd.Series(dtype="int")
        else:
            metrics = df_quality_file.apply(calculate_metrics, axis=1, result_type="expand")
            metrics_df = pd.DataFrame(metrics, index=df_quality_file.index)
            metrics_df = metrics_df.reindex(columns=[0, 1])
            metrics_df.columns = ["actualAnnotationsCount", "potentialNewAnnotationsCount"]
            metrics_df = metrics_df.fillna(0).astype(int)
            df_quality_file[["actualAnnotationsCount", "potentialNewAnnotationsCount"]] = metrics_df

        df_quality_file["coverageRate"] = (
            (
                df_quality_file["actualAnnotationsCount"]
                / (df_quality_file["actualAnnotationsCount"] + df_quality_file["potentialNewAnnotationsCount"])
            )
            * 100
        ).fillna(0)

        df_file_meta = fetch_annotation_states(annotation_state_view, file_view)
        df_display_unfiltered = (
            pd.merge(df_quality_file, df_file_meta, left_on="startNode", right_on="fileExternalId", how="left")
            if not df_file_meta.empty
            else df_quality_file
        )

        with st.expander("Filter Per-File Quality Table"):
            excluded_columns = [
                "Select",
                "startNode",
                "potentialTags",
                "actualAnnotations",
                "actualAnnotationsCount",
                "potentialNewAnnotationsCount",
                "coverageRate",
                "externalId",
                "space",
                "annotatedPageCount",
                "annotationMessage",
                "fileAliases",
                "fileAssets",
                "fileIsuploaded",
                "jobId",
                "linkedFile",
                "pageCount",
                "patternModeJobId",
                "sourceCreatedUser",
                "sourceCreatedTime",
                "sourceUpdatedTime",
                "sourceUpdatedUser",
                "fileSourceupdateduser",
                "fileSourcecreatedUser",
                "fileSourceId",
                "createdTime",
                "fileSourcecreateduser",
                "patternModeMessage",
                "fileSourceupdatedtime",
                "fileSourcecreatedtime",
                "fileUploadedtime",
            ]
            filterable_columns = sorted([col for col in df_display_unfiltered.columns if col not in excluded_columns])
            filter_col1, filter_col2 = st.columns(2)
            with filter_col1:
                selected_column = st.selectbox(
                    "Filter by Metadata Property",
                    options=["None"] + filterable_columns,
                    on_change=reset_selection,
                    key="per_file_filter",
                )
            selected_values = []
            if selected_column != "None":
                unique_values = sorted(df_display_unfiltered[selected_column].dropna().unique().tolist())
                with filter_col2:
                    selected_values = st.multiselect(
                        f"Select Value(s) for {selected_column}", options=unique_values, on_change=reset_selection
                    )
            coverage_range = st.slider(
                "Filter by Annotation Coverage (%)", 0, 100, (0, 100), on_change=reset_selection, key="coverage_slider"
            )

        df_display = df_display_unfiltered.copy()
        if selected_column != "None" and selected_values:
            df_display = df_display[df_display[selected_column].isin(selected_values)]
        df_display = df_display[
            (df_display["coverageRate"] >= coverage_range[0]) & (df_display["coverageRate"] <= coverage_range[1])
        ]
        df_display = df_display.reset_index(drop=True)
        df_display.insert(0, "Select", False)

        default_columns = [
            "Select",
            "fileName",
            "fileSourceid",
            "fileMimetype",
            "coverageRate",
            "annotationMessage",
            "patternModeMessage",
            "lastUpdatedTime",
        ]
        all_columns = df_display.columns.tolist()

        with st.popover("Customize Table Columns"):
            selected_columns = st.multiselect(
                "Select columns to display:",
                options=all_columns,
                default=[col for col in default_columns if col in all_columns],
            )
        if not selected_columns:
            st.warning("Please select at least one column to display.")
            st.stop()

        if st.session_state.get("selected_row_index") is not None and st.session_state.selected_row_index < len(
            df_display
        ):
            df_display.at[st.session_state.selected_row_index, "Select"] = True

        edited_df = st.data_editor(
            df_display[selected_columns],
            key="quality_table_editor",
            column_config={
                "Select": st.column_config.CheckboxColumn(required=True),
                "fileName": "File Name",
                "fileSourceid": "Source ID",
                "fileMimetype": "Mime Type",
                "fileExternalId": "File External ID",
                "coverageRate": st.column_config.ProgressColumn(
                    "Annotation Coverage ℹ️",
                    help="The percentage of all unique tags (both actual and potential) that have been successfully annotated. Formula: Total Actual Annotations / (Total Actual Annotations + Total Potential New Annotations)",
                    format="%.2f%%",
                    min_value=0,
                    max_value=100,
                ),
                "annotationMessage": "Annotation Message",
                "patternModeMessage": "Pattern Mode Message",
                "lastUpdatedTime": "Last Updated Time",
            },
            use_container_width=True,
            hide_index=True,
            disabled=df_display.columns.difference(["Select"]),
        )

        selected_indices = edited_df[edited_df.Select].index.tolist()
        if len(selected_indices) > 1:
            new_selection = [idx for idx in selected_indices if idx != st.session_state.get("selected_row_index")]
            st.session_state.selected_row_index = new_selection[0] if new_selection else None
            st.rerun()
        elif len(selected_indices) == 1:
            st.session_state.selected_row_index = selected_indices[0]
        elif len(selected_indices) == 0 and st.session_state.get("selected_row_index") is not None:
            st.session_state.selected_row_index = None
            st.rerun()

        st.divider()
        if st.session_state.get("selected_row_index") is not None and st.session_state.selected_row_index < len(
            df_display
        ):
            selected_file_data = df_display.iloc[st.session_state.selected_row_index]
            selected_file_ext_id = selected_file_data["startNode"]
            selected_file_name = selected_file_data["fileName"]
            st.markdown("**Displaying Tag Comparison for file:**")
            st.markdown(f"`{selected_file_name} ({selected_file_ext_id})`")
            file_space_series = df_patterns_file[df_patterns_file["startNode"] == selected_file_ext_id]["startNodeSpace"]
            if not file_space_series.empty:
                file_space = file_space_series.iloc[0]
                file_node_id = NodeId(space=file_space, external_id=selected_file_ext_id)
                df_potential_tags_details = df_patterns_file[df_patterns_file["startNode"] == selected_file_ext_id][
                    ["startNodeText", "endNodeResourceType", "status", "tags"]
                ]
                df_actual_annotations_details = (
                    df_annotations_file[df_annotations_file["startNode"] == selected_file_ext_id][
                        ["startNodeText", "endNodeResourceType"]
                    ]
                    if not df_annotations_file.empty
                    else pd.DataFrame(columns=["startNodeText", "endNodeResourceType"])
                )

                df_potential_details_candidate = df_potential_tags_details[df_potential_tags_details["status"].isin(["Suggested", "Reproved", "Rejected"]) ]
                df_potential_details_approved = df_potential_tags_details[df_potential_tags_details["status"] == "Approved"]

                potential_set = set(df_potential_details_candidate["startNodeText"].dropna())
                actual_from_table = set(df_actual_annotations_details["startNodeText"]) if not df_actual_annotations_details.empty else set()
                approved_in_file = set(df_potential_details_approved["startNodeText"].dropna()) if not df_potential_details_approved.empty else set()
                actual_set = actual_from_table.union(approved_in_file)

                norm_potential = {normalize(p) for p in potential_set}
                norm_actual = {normalize(a) for a in actual_set}

                potential_map = {normalize(text): text for text in potential_set}

                norm_unmatched = norm_potential - norm_actual

                potential_new_annotations_set = {potential_map[t] for t in norm_unmatched if t in potential_map}

                actual_df = df_actual_annotations_details.drop_duplicates()
                potential_df = df_potential_details_candidate[
                    df_potential_details_candidate["startNodeText"].isin({potential_map[t] for t in norm_unmatched})
                ].drop_duplicates(subset=["startNodeText", "endNodeResourceType"])

                potential_status_map_file = build_potential_status_map(df_potential_details_candidate)

                if not potential_df.empty:
                    potential_df = potential_df.copy()
                    potential_df["Status"] = potential_df["startNodeText"].apply(lambda t: potential_status_map_file.get(t, "Suggested"))

                if "tags" in df_potential_tags_details.columns:
                    df_approved_rows = (
                        df_potential_details_approved[["startNodeText", "endNodeResourceType", "tags", "status"]]
                        .drop_duplicates(subset=["startNodeText", "endNodeResourceType"])
                    ) if not df_potential_details_approved.empty else pd.DataFrame(columns=["startNodeText", "endNodeResourceType", "tags", "status"]) 
                else:
                    df_approved_rows = pd.DataFrame(columns=["startNodeText", "endNodeResourceType", "tags", "status"])

                if not df_approved_rows.empty:
                    df_approved_rows = df_approved_rows.copy()
                    df_approved_rows["Status"] = df_approved_rows.apply(
                        lambda r: derive_annotation_status(r.get("tags") if "tags" in r.index else None, row_status=r.get("status")),
                        axis=1,
                    )
                    df_approved_rows = df_approved_rows[["startNodeText", "endNodeResourceType", "Status"]]

                docs_rows = actual_df.copy() if not actual_df.empty else pd.DataFrame(columns=["startNodeText", "endNodeResourceType"])
                if not docs_rows.empty:
                    docs_rows = docs_rows.copy()
                    docs_rows["Status"] = "Regularly Annotated"

                combined_actual = pd.concat([df_approved_rows, docs_rows], ignore_index=True, sort=False)
                if not combined_actual.empty:
                    combined_actual = combined_actual.drop_duplicates(subset=["startNodeText"], keep="first")

                actual_df = combined_actual

                if st.button("Create in Canvas", key=f"canvas_btn_{selected_file_ext_id}"):
                    with st.spinner("Generating Industrial Canvas with bounding boxes..."):
                        potential_tags_for_canvas = build_unmatched_tags_with_regions(
                            df=df_metrics_input,
                            file_id=selected_file_ext_id,
                            potential_new_annotations=potential_new_annotations_set
                        )
                        canvas_url = generate_file_canvas(
                            file_id=file_node_id,
                            file_view=file_view,
                            ep_config=ep_config,
                            unmatched_tags_with_regions=potential_tags_for_canvas,
                        )
                        if canvas_url:
                            st.session_state["generated_canvas_url"] = canvas_url
                        else:
                            st.session_state.pop("generated_canvas_url", None)

                if "generated_canvas_url" in st.session_state and st.session_state.generated_canvas_url:
                    st.markdown(
                        f"**[Open Last Generated Canvas]({st.session_state.generated_canvas_url})**",
                        unsafe_allow_html=True,
                    )

                st.divider()
                col1, col2 = st.columns(2)
                with col1:
                    st.metric(
                        "✅ Actual Annotations in this File",
                        len(actual_df),
                    )
                    st.dataframe(
                        actual_df,
                        column_config={"startNodeText": "Tag", "endNodeResourceType": "Resource Type"},
                        use_container_width=True,
                        hide_index=True,
                    )
                with col2:
                    st.metric(
                        "💡 Potential New Annotations in this File",
                        len(potential_df),
                    )
                
                    unmatched_display = potential_df[["startNodeText", "endNodeResourceType", "Status"]].copy()
                    unmatched_display.insert(0, "Select", False)

                    occurrences = (
                        df_patterns_file[df_patterns_file["startNode"] == selected_file_ext_id].groupby("startNodeText")
                        .size()
                        .reset_index(name="occurrenceCount")
                    )

                    unmatched_display = unmatched_display.merge(occurrences, on="startNodeText", how="left")

                    if st.session_state.selected_unmatched_per_file_index is not None:
                        idx = st.session_state.selected_unmatched_per_file_index

                        if idx in unmatched_display.index:
                            unmatched_display.loc[:, "Select"] = False
                            unmatched_display.at[idx, "Select"] = True

                    unmatched_editor_key = "unmatched_tags_editor"
                    unmatched_data_editor = st.data_editor(
                        unmatched_display,
                        key=unmatched_editor_key,
                        column_config={
                            "Select": st.column_config.CheckboxColumn(required=True),
                            "startNodeText": "Tag",
                            "endNodeResourceType": "Resource Type",
                            "occurrenceCount": "Occurrences",
                            "Status": "Status",
                        },
                        use_container_width=True,
                        hide_index=True,
                        disabled=unmatched_display.columns.difference(["Select"]),
                    )

                    selected_indices = unmatched_data_editor[unmatched_data_editor.Select].index.tolist()

                    if len(selected_indices) > 1:
                        new_selection = [
                            idx for idx in selected_indices if idx != st.session_state.selected_unmatched_per_file_index
                        ]
                        st.session_state.selected_unmatched_per_file_index = new_selection[0] if new_selection else None
                        st.rerun()
                    elif len(selected_indices) == 1:
                        st.session_state.selected_unmatched_per_file_index = selected_indices[0]
                    elif len(selected_indices) == 0 and st.session_state.selected_unmatched_per_file_index is not None:
                        st.session_state.selected_unmatched_per_file_index = None
                        st.rerun()

                if st.session_state.selected_unmatched_per_file_index is not None:
                    selected_tag_row = unmatched_display.loc[st.session_state.selected_unmatched_per_file_index]
                    selected_tag_text = selected_tag_row["startNodeText"]
                    show_connect_unmatched_ui(
                        selected_tag_text,
                        file_view,
                        target_entities_view,
                        file_resource_property,
                        target_entities_resource_property,
                        associated_files=[selected_file_ext_id],
                        tab="per_file",
                        db_name=db_name,
                        pattern_table=pattern_table,
                        apply_config=apply_config,
                        annotation_state_view=annotation_state_view,
                        secondary_scope_prop=secondary_scope_property,
                    )

        else:
            st.info("✔️ Select a file in the table above to see a detailed breakdown of its tags.")

# ==========================================
#           PATTERN MANAGEMENT TAB
# ==========================================
with management_tab:
    primary_scope_prop = ep_config.get("launchFunction", {}).get("primaryScopeProperty")
    secondary_scope_property = ep_config.get("launchFunction", {}).get("secondaryScopeProperty")

    st.subheader(
        "Existing Manual Patterns",
        help="An action-oriented tool for improving pattern quality. After identifying missed tags in the other tabs, come here to add new manual patterns or edit existing ones to enhance the detection logic for future pipeline runs.",
    )
    df_manual_patterns_manage = fetch_manual_patterns(db_name, manual_patterns_table)

    edited_df_manage = st.data_editor(
        df_manual_patterns_manage,
        num_rows="dynamic",
        use_container_width=True,
        column_config={
            "key": st.column_config.TextColumn("Scope Key", disabled=True),
            "sample": st.column_config.TextColumn("Pattern String", required=True),
            "annotation_type": st.column_config.SelectboxColumn(
                "Annotation Type", options=["diagrams.FileLink", "diagrams.AssetLink"], required=True
            ),
            "resource_type": st.column_config.TextColumn("Resource Type", required=True),
            "scope_level": st.column_config.SelectboxColumn(
                "Scope Level",
                options=["Global", "Primary Scope", "Secondary Scope"],
                required=True,
            ),
            "primary_scope": st.column_config.TextColumn("Primary Scope"),
            "secondary_scope": st.column_config.TextColumn("Secondary Scope"),
            "created_by": st.column_config.TextColumn("Created By", required=True),
        },
    )

    if st.button("Save Changes", type="primary", key="save_patterns"):
        with st.spinner("Saving changes to RAW..."):
            try:
                save_manual_patterns(edited_df_manage, db_name, manual_patterns_table)
                st.success("Changes saved successfully!")
                st.cache_data.clear()
                st.rerun()
            except Exception as e:
                st.error(f"Failed to save changes: {e}")

    st.divider()

    st.subheader("Add a New Pattern")
    scope_level = st.selectbox(
        "1. Select Scope Level", ["Global", "Primary Scope", "Secondary Scope"], key="scope_level_selector"
    )

    with st.form(key="new_pattern_form", clear_on_submit=True):
        st.write("2. Enter Pattern Details")
        new_pattern = st.text_input("Pattern String", placeholder="e.g., [PI]-00000")
        new_annotation_type = st.selectbox(
            "Annotation Type", ["diagrams.FileLink", "diagrams.AssetLink"], key="new_annotation_type_selector"
        )
        new_resource_type = st.text_input("Resource Type", placeholder="e.g., Asset")

        primary_scope_value = ""
        if scope_level in ["Primary Scope", "Secondary Scope"]:
            primary_scope_value = st.text_input(f"Primary Scope Value ({primary_scope_prop or 'not configured'})")

        secondary_scope_value = ""
        if scope_level == "Secondary Scope":
            secondary_scope_value = st.text_input(f"Secondary Scope Value ({secondary_scope_property or 'not configured'})")

        submit_button = st.form_submit_button(label="Add New Pattern")

        if submit_button:
            if not all([new_pattern, new_resource_type]):
                st.warning("Pattern String and Resource Type are required.")
            else:
                with st.spinner("Adding new pattern..."):
                    try:
                        new_row = pd.DataFrame(
                            [
                                {
                                    "sample": new_pattern,
                                    "resource_type": new_resource_type,
                                    "scope_level": scope_level,
                                    "annotation_type": new_annotation_type,
                                    "primary_scope": primary_scope_value,
                                    "secondary_scope": secondary_scope_value,
                                    "created_by": "streamlit",
                                }
                            ]
                        )
                        updated_df = pd.concat([edited_df_manage, new_row], ignore_index=True)

                        save_manual_patterns(updated_df, db_name, manual_patterns_table)
                        st.success("New pattern added successfully!")
                        st.cache_data.clear()
                        st.rerun()
                    except Exception as e:
                        st.error(f"Failed to add pattern: {e}")
