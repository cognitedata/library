BATCH_SIZE = -1 # Number oin one batch read from sync api, must be greater or equal to 100
TS_NODE = "timeseries"
ASSET_NODE = "assets"
