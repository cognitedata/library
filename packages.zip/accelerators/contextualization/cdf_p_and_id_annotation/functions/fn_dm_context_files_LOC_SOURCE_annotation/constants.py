FILE_LINK_EXTERNAL_ID = "diagrams.FileLink"
STAT_STORE_CURSOR = "state_file_cursor"
STAT_STORE_NUM_IN_BATCH = "state_num_in_batch"
STAT_STORE_VALUE = "value"
BATCH_SIZE = 100 # Number of documents in one batch read from sync api, must be greater or equal to 100
ANNOTATE_BATCH_SIZE = 10 # Number of documents in one annotation batch, must be less than 50
EXTERNAL_ID_LIMIT = 256
FUNCTION_ID="fn_dm_p_and_id_annotation"
