STAT_STORE_VALUE = "value"
STAT_STORE_FILE_CURSOR = "state_file_meta_cursor"
STAT_STORE_ASSET_CURSOR = "state_asset_meta_cursor"
BATCH_SIZE = 1000 # Number of documents in one batch read from sync api, must be greater or equal to 100
FILE_NODE = "files"
ASSET_NODE = "assets"
