# Un-migrated wizard strings

All strings identified during the Japanese-localisation migration are now wired
through the `t()` message catalogue. This file is kept as a record of what was
found and how it was resolved — update it if a future audit finds a new gap.

## Draft (not yet VD-team-reviewed) translations

Everything below was originally left out of the PRD's reviewed
`japanese_localization_strings.csv` scope — internal crashes and a couple of
checklist strings the review predated. They're now wired in using **draft**
translations from `cdf_queries/unmigrated_localization_strings.csv`, which is
**not yet reviewed by the Japanese VD team**. Update that CSV and regenerate
`_messages_ja.py` if the review changes any of the wording.

- **`_pack_config.py`**: `detect_data_model_variant()`'s multiple-data-models
  error, `load_yaml()`'s YAML-parse-failure error.
- **`generate_actions.py`**: the Azure DevOps "Next steps" checklist (3
  ADO-specific lines; the shared `(see docs/FOUNDATION_CICD.md)` line reuses the
  already-reviewed GitHub-path translation, not a new draft), and the internal
  `ValueError`/`FileNotFoundError` config/argument validation errors (unsupported
  `--provider`, no modules directory, no `cdf.toml`, unfilled template
  placeholders, `environment.name`/`environment.project` mismatches, no
  `config.<env>.yaml` files found, two environments mapping to the same deploy
  branch, unsupported number of deployable branches).
- **`setup_project.py`**: the pack-kind-ambiguous crash, the two "no
  environments selected" crashes, `_warn_if_no_email()`'s message, and the
  `_warn_disabled_notifications()` block.

## Known limitations worth flagging to the VD team

- **`resolve_pack_kind_for_check()`'s ambiguous-pack-kind error** and the
  **`_warn_disabled_notifications()` block** are only ever called from
  `_run_check()`, which AT-113 wraps in `_i18n.locale_override("en")` — `--check`
  always forces English. Their draft translations are wired in and exercised by
  tests, but never selected in practice unless that design decision changes.
- **`_warn_if_no_email()`**'s `{label}` argument (e.g. `"integration owner"`,
  `"data owner (PI Extractor)"`) is passed as a raw, untranslated English literal
  at the call site — the wrapper sentence is now Japanese, but the embedded label
  itself still prints in English. Fixing that means adding catalogue entries for
  the lowercase label variants and routing `_prompt_source_system_ownership()`'s
  calls to `_warn_if_no_email()` through `t()` too — not done here, since those
  labels aren't in either reviewed CSV yet.
