# Foundation Deployment Pack — CI/CD setup

Generated from committed Toolkit environment configs.

This follows the [CDF Foundation Setup guide](https://cogdocs.mintlify.io/gvd) *(password-protected — request access via [#topic-deployment-packs](https://cognitedata.slack.com/archives/C098QJ09YKX) or contact [Valeriya Naumova](https://cognitedata.slack.com/team/U051XA95S0G))* — Step 5.

## Branching model

| Git branch / event | CDF project | Trigger |
|--------------------|-------------|---------|
{{BRANCHING_ROWS}}

If a pre-production environment is present, PRs to `main` must come from `dev` or `hotfix/*` only.

## Branch protection

Protect the branches used above under **Settings → Branches**. This is required, not optional:

| Branch | Required reviewers | Required status checks |
|--------|---------------------|--------------------------|
{{BRANCH_PROTECTION_ROWS}}

{{BRANCH_PROTECTION_NOTE}}

## GitHub Environments

Create the generated environments under **Settings → Environments**:

| Environment | Used by | `CDF_PROJECT` example |
|-------------|---------|-------------------------|
{{ENVIRONMENT_ROWS}}

Each environment needs these **variables**:

- `CDF_CLUSTER`
- `CDF_PROJECT` (must match `config.<env>.yaml`)
- `LOGIN_FLOW` (typically `client_credentials`)
- `IDP_TENANT_ID`
- `IDP_CLIENT_ID`
- `ADMIN_SOURCE_ID`
- `CONSUMER_SOURCE_ID`
- `PRODUCER_SOURCE_ID`

And this **secret**:

- `IDP_CLIENT_SECRET`

## Toolkit configs

This generator only writes GitHub Actions workflows and this guide. It does not
create or refresh {{ENV_CONFIG_LIST}}.

Before opening a PR, run the project setup wizard and commit the resulting config
files together with the workflows:

```bash
python modules/common/cdf_project_foundation/scripts/setup_project.py
cdf build {{EXAMPLE_BUILD_ARGS}}
```

CI validates the committed configs as-is; it does not regenerate them.
If the repository does not have a root `.pre-commit-config.yaml`, the generated
PR workflow skips the pre-commit config lint step.

If any CDF Function under a `functions/` folder has Python source, the PR workflow
also runs `ruff check` and `pyright` against it, installing each function's
`requirements.txt` first so imports resolve. Projects with no `functions/` Python
code skip this step.

## Regenerate workflows

```bash
python modules/common/cdf_project_foundation/scripts/generate_actions.py --force
```

## Toolkit version

Workflows install `cognite-toolkit=={{TOOLKIT_VERSION}}`. Keep in sync with `[modules].version` in `cdf.toml`.
