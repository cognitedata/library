# OPC-UA Extractor Module

This module ingests OPC-UA node metadata, references, and subscription state into CDF RAW. OPC-UA timeseries values (measurements) are written directly to CDF by the OPC-UA Extractor — RAW is used for node metadata (name, description, data type), reference structure, and extractor browse/state caches to provide an audit trail and enable downstream contextualization. Transformations from RAW into the ISA Manufacturing Extension data model are not shipped here; author them downstream as needed.


> **Node filters must be configured before production use.** Without filters the extractor browses the full OPC-UA server tree, which may be very large and slow. See the extractor config for commented-out examples.

## Module Architecture

```
cdf_opcua_extractor/
├── auth/
│   └── producer.ep.opcua.Group.yaml              # Scoped extractor service-principal group
├── data_modeling/
│   └── sp_opcua_extractor.Space.yaml             # Per-extractor DM instance space
├── extraction_pipelines/
│   ├── ep_opcua.ExtractionPipeline.yaml          # Pipeline definition with RAW table references
│   └── ep_opcua.ExtractionPipeline.Config.yaml   # Full OPC-UA Extractor config template
├── raw/
│   └── db_opcua.Database.yaml                    # raw_timeseries_{{location}}_{{sourceSystem}}
└── module.toml
```

> **Note:** This extractor module ingests OPC-UA data into RAW (and Asset/TS
> directly). Transformations from RAW into the ISA Manufacturing Extension data
> model are not yet shipped with this module — see
> `.cursor/rules/cdf-transformations.mdc` for guidance on authoring them.

## Data Flow

```
OPC-UA Server
      │
      ▼
OPC-UA Extractor
      │
      ├── Variable values  ──────────► CDF Timeseries (direct write)
      ├── Object nodes     ──────────► RAW: assets
      ├── Variable nodes   ──────────► RAW: timeseries
      ├── References       ──────────► RAW: relationships
      ├── Browse cache     ──────────► RAW: known_objects, known_references, known_variables
      └── Subscription state ────────► RAW: state_store_variables
```

## Resources Created

| Resource | External ID | Purpose |
|---|---|---|
| ExtractionPipeline | `ep_timeseries_{{location}}_{{sourceSystem}}` | Pipeline health tracking and config delivery |
| RAW Database | `raw_timeseries_{{location}}_{{sourceSystem}}` | OPC-UA node metadata + state landing zone |
| DM Space | `{{instanceSpace}}` | Per-extractor instance space for DM instances |
| Access Group | `producer_{{location}}_ep_opcua_{{sourceSystem}}_{{environment}}` | Scoped service-principal group — one per extractor type × source system |

Names follow the [CDF resource naming conventions](https://docs.cognite.com/cdf/deploy/reference/cdf_resource_naming_conventions):
pipelines use `ep_{data_type}_{location}_{source}` and access groups use the persona-led
pattern `producer_[{site}_]ep_{extractortype}_{sourcesystem}_{environment}`.
Both the pipeline and the RAW database use the `timeseries` data type. Datapoints go
straight to `CogniteTimeSeries`; the RAW database only holds metadata (Variable and Object
node metadata, references) and extractor state.

The producer group follows the least-privilege scoping in the GVD data onboarding SOP:
`extractionConfigs:READ`, `extractionRuns:WRITE`, and `extractionPipelines:READ` on the
pipeline's data set, with no `extractionPipelines:WRITE`. There is no `sessions:CREATE`
either: the extractor authenticates with its own client credentials, and
[sessions](https://docs.cognite.com/api-reference/concepts/20230101/sessions) are only
needed by background workloads such as transformations, functions, and workflows.

## Configuration

All variables are declared locally in `config.<env>.yaml` (no inheritance):

```yaml
variables:
  modules:
    cdf_opcua_extractor:
      location: "oslo"                                        # Site code, used in externalIds (ep_timeseries_<location>_<sourceSystem>, raw_timeseries_<location>_<sourceSystem>)
      sourceSystem: "scada"                                   # Source system token, used in the pipeline ID and group name
      instanceSpace: "inst_oslo_opcua"                         # Per-extractor DM instance space — computed by setup_project.py
      dataset: "ds_opcua_oslo"                               # ds_<data_type>_<location> — computed by setup_project.py

      integration_owner_name: "Integration Owner"             # Technical contact for the pipeline
      integration_owner_email: "integration.owner@example.com"

      data_owner_name: "Data Owner"                           # Business contact for the data
      data_owner_email: "data.owner@example.com"
```

## Environment Variables

Set these on the host running the OPC-UA Extractor:

| Variable | Description |
|---|---|
| `OPCUA_ENDPOINT_URL` | OPC-UA server URL, e.g. `opc.tcp://192.168.1.10:4840` |
| `OPCUA_USER` | OPC-UA server username |
| `OPCUA_PASSWORD` | OPC-UA server password |
| `CDF_PROJECT` | CDF project name |
| `CDF_URL` | CDF base URL (e.g. `https://api.cognitedata.com`) |
| `IDP_TENANT_ID` | IDP tenant ID |
| `IDP_CLIENT_ID` | Service account client ID |
| `IDP_CLIENT_SECRET` | Service account client secret |

## Verify Before Deploy

OPC-UA node structure is highly site-specific. The extractor config ships with
sensible defaults but several aspects must be configured before production use:

1. **Node filters** — without filters the extractor browses the entire server
   tree, which can be very large on industrial OPC-UA servers. Obtain the
   namespace and node IDs from the site OPC-UA administrator (or browse with a
   tool like UA Expert), then uncomment and adapt the
   `extraction.transformations` block in
   `ep_opcua.ExtractionPipeline.Config.yaml`. Start with `Include` rules for
   the Object nodes that contain your data, then `Include` the Variable nodes
   you need.
2. **Endpoint URLs** — the documentation block in
   `ep_opcua.ExtractionPipeline.yaml` lists primary/secondary endpoints as
   examples; replace with the actual server addresses for your site.
3. **Certificate storage** — by default the OPC-UA extractor stores
   certificates in the OS user store. For service-account deployments, edit
   `config/opc.ua.net.extractor.Config.xml` to point at a known directory (see
   the install instructions in `ep_opcua.ExtractionPipeline.yaml`).

See `.cursor/rules/cdf-transformations.mdc` for AI-assisted guidance when
authoring the downstream transformations into ISA Manufacturing Extension.

## Getting Started

### Prerequisites

- `models/isa_manufacturing_extension` deployed (downstream target)
- OPC-UA Extractor installed and network-accessible to the OPC-UA server
- Extractor service account with read/write to the `raw_timeseries_{{location}}_{{sourceSystem}}` RAW
  database and read access to the `{{dataset}}` data set
- Node filters configured in the extractor config

### Deploy

```bash
cdf deploy modules/sourcesystem/cdf_opcua_extractor --env your-environment
```

### Configure and run the extractor

The extractor config is delivered via the `ep_timeseries_{{location}}_{{sourceSystem}}` extraction pipeline in CDF. Set the environment variables on the extractor host and start the extractor — it will pull its config from CDF automatically.

### Migrating from earlier versions

The pipeline external ID changed from `ep_{{location}}_opcua` to
`ep_timeseries_{{location}}_{{sourceSystem}}`, and the access group from
`producer_{{location}}_ep_opcua_{{environment}}` to
`producer_{{location}}_ep_opcua_{{sourceSystem}}_{{environment}}`. To upgrade an existing
deployment:

1. Add `sourceSystem` to `cdf_opcua_extractor` in each `config.<env>.yaml`.
2. Run `cdf deploy`. This creates the new pipeline and group alongside the old ones.
3. Update `extraction-pipeline.pipeline-id` in the extractor host's local `config.yaml`,
   then restart the extractor.
4. Once the extractor reports runs on the new pipeline, delete the old pipeline and group
   in Fusion. Toolkit does not remove them for you, and the new group keeps the same
   `sourceId`, so no IdP change is needed.

The RAW database also changed from `db_{{location}}_opcua` to
`raw_timeseries_{{location}}_{{sourceSystem}}`, and the state-store tables from
`state-store-variables` / `state-store-events` to `state_store_variables` /
`state_store_events`. The browse caches and state stores live in that database, so the
extractor starts with an empty state: expect a full browse and a history re-read on first
start. Point any downstream transformations at the new name, then delete the old database.

The instance space also changed from `sp_{{location}}_opcua` to `inst_{{location}}_opcua`
(`setup_project.py` writes the new name on its next run). Instances already in the old
space are not moved: the extractor creates new instances in the new space on its next
run and reads history into them according to the `history` settings in `Config.yaml`.
Verify the new instances, then delete the old space. To keep the old space instead, set
`instanceSpace` back to its old value after running the wizard;
`setup_project.py --check` then reports it as drift.

The producer group's capabilities were also narrowed (see [Resources Created](#resources-created)).
If anything else uses this group's service principal, check that it does not rely on the
removed capabilities.
