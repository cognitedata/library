SELECT
  cast(key as string) as externalId,
  cast(name as string) as name,
  cast(description as string) as description,
  cast(tagNumber as string) as tagNumber,
  cast(area as string) as area,
  cast(facility as string) as facility,
  cast(system as string) as system,
  cast(parentTag as string) as parentTag,
  cast(classId as string) as classId,
  cast(className as string) as className,
  cast(tagDiscipline as string) as tagDiscipline,
  cast(project as string) as project,
  cast(classViewExtId as string) as classViewExtId,
  cast(originatingContractor as string) as originatingContractor,
  cast(updatedDate as string) as updatedDate,
  cast(dateInstalled as string) as dateInstalled,
  cast(useProjectStatus as string) as useProjectStatus,
  cast(purchaseOrderNo as string) as purchaseOrderNo,
  cast(avejaTagStatus as string) as avevaTagStatus,
  cast(cfihosTagClassCode as string) as cfihosTagClassCode,
  CASE
    WHEN parentTag IS NULL OR parentTag = '' THEN NULL
    ELSE node_reference('{{ instance_space }}', cast(parentTag as string))
  END as parent,
  CASE
    WHEN labels IS NULL OR trim(cast(labels as string)) = '' THEN array('DetectInDiagrams')
    ELSE array(cast(labels as string), 'DetectInDiagrams')
  END as tags,
  FILTER(
    array(cast(name as string), cast(tagNumber as string)),
    x -> x IS NOT NULL AND trim(x) != ''
  ) as aliases,
  cast(key as string) as sourceId,
  'cfihos_test' as sourceContext
FROM `cfihos_oil_and_gas`.`tag`
WHERE 1=1 -- full reload: is_new('tag', lastUpdatedTime)
