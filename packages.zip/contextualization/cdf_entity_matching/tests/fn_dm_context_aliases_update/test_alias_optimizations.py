#!/usr/bin/env python3
"""
Comprehensive Test Suite for Metadata Update Optimizations

This script tests all optimization features for both entity matching and P&ID annotation
metadata update functions without requiring a full CDF environment setup.
"""

import sys
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.append(str(Path(__file__).resolve().parents[2] / "functions" / "fn_dm_context_aliases_update"))

from cognite.client.data_classes.data_modeling import NodeApply, ViewId
from cognite.client.exceptions import CogniteAPIError, CogniteConnectionError

from constants import DEFAULT_ALIAS_PATTERN  # isort: skip
from logger import CogniteFunctionLogger  # isort: skip
from alias_optimizations import (  # isort: skip
    BatchProcessor,
    AliasRule,
    OptimizedMetadataProcessor,
    _unmanaged_aliases,
    time_operation,
)


class TestPerformanceMonitoring(unittest.TestCase):
    """Test performance monitoring utilities"""

    def setUp(self) -> None:
        self.logger = CogniteFunctionLogger("DEBUG")

    def test_time_operation(self) -> None:
        """Test timing context manager"""
        print("🧪 Testing time_operation...")

        with time_operation("Test operation", self.logger):
            time.sleep(0.1)

        print("✅ time_operation test passed")


class TestBatchProcessing(unittest.TestCase):
    """Test batch processing utilities"""

    def setUp(self) -> None:
        self.logger = CogniteFunctionLogger("DEBUG")

    def test_apply_updates_chunks_by_constructor_batch_size(self) -> None:
        """Updates are applied in chunks of the batch size given to the constructor"""
        client = MagicMock()
        updates = [NodeApply(space="sp", external_id=f"item-{i}") for i in range(7)]

        applied = BatchProcessor(batch_size=3).apply_updates_in_batches(client, updates, self.logger)

        self.assertEqual(applied, 7)
        batch_sizes = [len(call.args[0]) for call in client.data_modeling.instances.apply.call_args_list]
        self.assertEqual(batch_sizes, [3, 3, 1])

    def test_apply_updates_with_no_updates(self) -> None:
        """An empty update list applies nothing"""
        client = MagicMock()

        applied = BatchProcessor().apply_updates_in_batches(client, [], self.logger)

        self.assertEqual(applied, 0)
        client.data_modeling.instances.apply.assert_not_called()

    def test_a_rejected_property_is_not_retried_or_split(self) -> None:
        """A misconfigured property fails the same way in a smaller batch, so try it once.

        Retrying and then splitting spends a minute of the function's runtime on a
        request the API can never accept, and buries the one message that explains why.
        """
        client = MagicMock()
        client.data_modeling.instances.apply.side_effect = CogniteAPIError(
            "Property 'labels' does not exist in view 'cdf_cdm:CogniteAsset/v1'", code=400
        )
        updates = [NodeApply(space="sp", external_id=f"item-{i}") for i in range(4)]

        with patch("tenacity.nap.time.sleep"), self.assertRaises(CogniteAPIError) as caught:
            BatchProcessor(batch_size=4).apply_updates_in_batches(client, updates, self.logger)

        self.assertIn("does not exist in view", str(caught.exception))
        self.assertEqual(client.data_modeling.instances.apply.call_count, 1)

    def test_a_batch_the_api_calls_too_large_is_split_at_any_batch_size(self) -> None:
        """Splitting takes a quarter of the batch size, which rounds to zero below four.

        The chunk size then has to stay at least one, or the split loop raises a
        ValueError that buries the API error it was trying to recover from.
        """
        client = MagicMock()
        client.data_modeling.instances.apply.side_effect = [
            CogniteAPIError("Request too large", code=413),
            None,
        ]
        updates = [NodeApply(space="sp", external_id="item-0")]

        with patch("tenacity.nap.time.sleep"):
            applied = BatchProcessor(batch_size=1).apply_updates_in_batches(client, updates, self.logger)

        self.assertEqual(applied, 1)
        self.assertEqual(client.data_modeling.instances.apply.call_count, 2)

    def test_a_dropped_connection_is_retried(self) -> None:
        """A connection error carries no status code, and the next attempt may connect."""
        client = MagicMock()
        client.data_modeling.instances.apply.side_effect = [
            CogniteConnectionError("Connection reset"),
            None,
        ]
        updates = [NodeApply(space="sp", external_id="item-0")]

        with patch("tenacity.nap.time.sleep"):
            applied = BatchProcessor(batch_size=1).apply_updates_in_batches(client, updates, self.logger)

        self.assertEqual(applied, 1)
        self.assertEqual(client.data_modeling.instances.apply.call_count, 2)

    def test_a_bug_is_not_retried(self) -> None:
        """A bug in our own code fails identically every attempt, so it fails once."""
        client = MagicMock()
        client.data_modeling.instances.apply.side_effect = TypeError("bad argument")
        updates = [NodeApply(space="sp", external_id="item-0")]

        with patch("tenacity.nap.time.sleep"), self.assertRaises(TypeError):
            BatchProcessor(batch_size=1).apply_updates_in_batches(client, updates, self.logger)

        self.assertEqual(client.data_modeling.instances.apply.call_count, 1)

    def test_a_rate_limited_batch_is_still_retried(self) -> None:
        """Rate limiting is transient, so it keeps its retry."""
        client = MagicMock()
        client.data_modeling.instances.apply.side_effect = [
            CogniteAPIError("Too many requests", code=429),
            None,
        ]
        updates = [NodeApply(space="sp", external_id="item-0")]

        with patch("tenacity.nap.time.sleep"):
            applied = BatchProcessor(batch_size=1).apply_updates_in_batches(client, updates, self.logger)

        self.assertEqual(applied, 1)
        self.assertEqual(client.data_modeling.instances.apply.call_count, 2)


# A site-specific pattern used to check that configuration, not the built-in default,
# decides the alias. The "-" in the separator class is deliberate: the generated alias
# joins the groups with "-", and the pattern has to match that to recognise its own work.
PUMP_PATTERN = r"([A-Z]{3})[-_]?(\d{4})"

# The document number patterns shipped in the module's default.config.yaml, for
# fileAliasPattern. Kept in sync by hand; the tests below pin the behaviour they promise.
DOCUMENT_PATTERNS = [
    r"(?<![A-Z])([A-Z]{2,4}[-_][0-9]+[-_][A-Z][-_][0-9]+[-_][0-9]+)",
    r"(?<![A-Z])([A-Z]{2,4}[-_][0-9]+[-_][A-Z][-_][0-9]+)(?:[-_][0-9]+)?",
    r"([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})",
]

# The equipment tag patterns shipped in the module's default.config.yaml, for
# assetAliasPattern. The first one reads the tag without its unit prefix, so a name such
# as 23-DB-9101 has to yield both the short and the full tag under 'all'.
SHIPPED_ASSET_PATTERNS = [
    r"([A-Z]{2,4}[-_.:][0-9]{4,5})",
    r"([0-9]{2}[-_.:][A-Z]{2,4}[-_.:][0-9]{4,5}[A-Z][-_][A-Z]{1,3})",
    r"([0-9]{2}[-_.:][A-Z]{2,4}[-_.:][0-9]{4,5}[-_][A-Z]{1,3})",
    r"([0-9]{2}[-_.:][A-Z]{2,4}[-_.:][0-9]{4,5})",
]


class TestOptimizedMetadataProcessor(unittest.TestCase):
    """Test optimized metadata processing"""

    def setUp(self) -> None:
        self.logger = CogniteFunctionLogger("DEBUG")
        self.processor = OptimizedMetadataProcessor(self.logger)
        self.view_id = ViewId(space="cdf_cdm", external_id="CogniteTimeSeries", version="v1")
        self.file_view_id = ViewId(space="cdf_cdm", external_id="CogniteFile", version="v1")

    def test_timeseries_alias_enrichment(self) -> None:
        """Test timeseries metadata updates aliases only"""
        print("🧪 Testing timeseries alias enrichment...")

        node = MagicMock()
        node.external_id = "pi:160001"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                "description": "existing description",
                "aliases": ["existing"],
                "tags": ["existing:tag"],
            }
        }

        result = self.processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNotNone(result)
        properties = result.sources[0].properties
        self.assertIn("aliases", properties)
        self.assertIn("23-KA-9101", properties["aliases"])
        self.assertNotIn("tags", properties)
        self.assertNotIn("description", properties)

        print("✅ Timeseries alias enrichment test passed")

    def test_every_matching_pattern_contributes_an_alias(self) -> None:
        """Names that follow two conventions at once yield an alias for each."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN, PUMP_PATTERN]),
        )
        node = MagicMock()
        node.external_id = "pi:160020"
        node.properties = {self.view_id: {"name": "VAL_23-KA-9101_PMP1234", "aliases": []}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101", "PMP-1234"])

    def test_longest_selection_keeps_only_the_most_specific_alias(self) -> None:
        """With overlapping conventions, the longest match is the most specific one."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN, PUMP_PATTERN], selection="longest"),
        )
        node = MagicMock()
        node.external_id = "pi:160021"
        node.properties = {self.view_id: {"name": "VAL_23-KA-9101_PMP1234", "aliases": []}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101"])

    def test_equally_long_aliases_are_resolved_by_configured_order(self) -> None:
        """A tie must not depend on dict or set ordering, so the first pattern wins."""
        first = r"([A-Z]{3})[-_]?(\d{4})"
        second = r"(\d{4})[-_]?([A-Z]{3})"
        node = MagicMock()
        node.external_id = "pi:160022"
        node.properties = {self.view_id: {"name": "PMP1234 and 5678XYZ", "aliases": []}}

        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([second, first], selection="longest")
        )
        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["5678-XYZ"])

    def test_update_all_reclaims_aliases_from_every_configured_pattern(self) -> None:
        """Selecting only the longest must not orphan aliases an earlier run wrote."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN, PUMP_PATTERN], selection="longest"),
        )
        node = MagicMock()
        node.external_id = "pi:160023"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101_PMP1234",
                # PMP-1234 was written when the mode was "all"; it is still ours to remove.
                "aliases": ["operator note", "23-KA-9101", "PMP-1234"],
            }
        }

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertEqual(result.sources[0].properties["aliases"], ["operator note", "23-KA-9101"])

    def test_letter_prefixed_aliases_are_normalized(self) -> None:
        """Separators are rewritten for every generated alias, not only two-digit tags."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            asset_alias_rule=AliasRule.from_config(SHIPPED_ASSET_PATTERNS, selection="all"),
        )
        asset_view = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-DB-9101"
        node.properties = {asset_view: {"name": "23-DB-9101", "aliases": ["23-DB-9101", "DB-9101"]}}

        result = processor.process_asset_metadata(node, asset_view, "inst_location", update_all=True)

        self.assertEqual(result.sources[0].properties["aliases"], ["DB-9101", "23-DB-9101"])

    def test_a_single_group_tag_pattern_still_normalizes_separators(self) -> None:
        """One capture group for the whole tag must still yield hyphens between tokens."""
        single_group = r"([0-9]{2}[-_.:][A-Z]{2,4}[-_.:][0-9]{4,5})"
        processor = OptimizedMetadataProcessor(
            self.logger,
            timeseries_alias_rule=AliasRule.from_config([single_group]),
            asset_alias_rule=AliasRule.from_config([single_group]),
            file_alias_rule=AliasRule.from_config([single_group]),
        )
        ts_node = MagicMock()
        ts_node.external_id = "pi:160040"
        ts_node.properties = {self.view_id: {"name": "VAL_23-KA-9101:X.Value", "aliases": []}}

        asset_view = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        asset_node = MagicMock()
        asset_node.external_id = "23-KA-9101"
        asset_node.properties = {asset_view: {"name": "23-KA-9101", "aliases": []}}

        file_node = MagicMock()
        file_node.external_id = "file:4020"
        file_node.properties = {self.file_view_id: {"name": "23-KA-9101.pdf", "aliases": []}}

        ts_result = processor.process_timeseries_metadata(ts_node, self.view_id, "inst_location")
        asset_result = processor.process_asset_metadata(asset_node, asset_view, "inst_location")
        file_result = processor.process_file_metadata(file_node, self.file_view_id, "inst_location")

        self.assertEqual(ts_result.sources[0].properties["aliases"], ["23-KA-9101"])
        self.assertEqual(asset_result.sources[0].properties["aliases"], ["23-KA-9101"])
        self.assertEqual(
            file_result.sources[0].properties["aliases"],
            ["23-KA-9101"],
        )

    def test_configured_pattern_drives_timeseries_alias_generation(self) -> None:
        """A site whose tags do not follow the default shape configures its own pattern."""
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))
        node = MagicMock()
        node.external_id = "pi:160010"
        node.properties = {self.view_id: {"name": "PMP1234 discharge pressure", "aliases": []}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["PMP-1234"])

    def test_an_unmatched_optional_group_is_left_out_of_the_alias(self) -> None:
        """A configured pattern may make a group optional, and then it captures None.

        Joining that straight into the alias raises a TypeError, so a name matching only
        the mandatory part of the pattern would take the whole run down.
        """
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([r"([A-Z]{3})?[-_]?(\d{4})"])
        )
        node = MagicMock()
        node.external_id = "pi:160030"
        node.properties = {self.view_id: {"name": "1234 discharge pressure", "aliases": []}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["1234"])

    def test_a_name_holding_no_tag_leaves_aliases_empty(self) -> None:
        """A name no pattern reads produces no alias."""
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        node = MagicMock()
        node.external_id = "pi:160031"
        node.properties = {self.view_id: {"name": "Reactor outlet temperature", "aliases": []}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_an_asset_name_holding_no_tag_leaves_aliases_empty(self) -> None:
        """Assets leave aliases empty when no pattern matches."""
        processor = OptimizedMetadataProcessor(
            self.logger, asset_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        asset_view = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "pump-a"
        node.properties = {asset_view: {"name": "Feed pump A", "aliases": []}}

        result = processor.process_asset_metadata(node, asset_view, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def _process_names_without_alias(self, processor: OptimizedMetadataProcessor, count: int) -> None:
        """Run `count` timeseries whose names no configured pattern reads."""
        for i in range(count):
            node = MagicMock()
            node.external_id = f"pi:{i}"
            node.properties = {self.view_id: {"name": f"Reactor outlet {i}", "aliases": []}}
            processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

    def test_the_missing_alias_warning_stops_after_ten_names(self) -> None:
        """A naming convention no pattern covers must not bury the rest of the run log."""
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))

        with patch.object(self.logger, "warning") as warning:
            self._process_names_without_alias(processor, 12)
            self.assertEqual(warning.call_count, 10)

            processor.log_missing_alias_summary()
            self.assertIn("12", warning.call_args.args[0])

    def test_no_summary_is_logged_when_no_warning_was_suppressed(self) -> None:
        """With nothing held back, a total only repeats what the log already shows."""
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))

        with patch.object(self.logger, "warning") as warning:
            self._process_names_without_alias(processor, 3)
            processor.log_missing_alias_summary()

        self.assertEqual(warning.call_count, 3)

    def test_a_suppressed_warning_still_leaves_aliases_empty(self) -> None:
        """Throttling the log must not change that no alias is written."""
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))
        self._process_names_without_alias(processor, 10)

        node = MagicMock()
        node.external_id = "pi:beyond-the-cap"
        node.properties = {self.view_id: {"name": "Reactor outlet temperature", "aliases": []}}
        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_an_instance_that_already_has_an_alias_is_unchanged_when_no_pattern_matches(self) -> None:
        """Hand-curated aliases are kept when the name does not match the pattern."""
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        node = MagicMock()
        node.external_id = "pi:160033"
        node.properties = {self.view_id: {"name": "Reactor outlet temp", "aliases": ["spare for 23-AB-1234"]}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_a_renamed_instance_keeps_a_hand_curated_alias_under_update_all(self) -> None:
        """updateAll keeps hand-curated aliases that do not round-trip through the pattern.

        When the rebuilt list matches what is already stored, no DM write is issued.
        """
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        node = MagicMock()
        node.external_id = "pi:160034"
        node.properties = {self.view_id: {"name": "Reactor outlet temperature", "aliases": ["Reactor outlet temp"]}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertIsNone(result)

    def test_a_produced_alias_already_in_org_is_not_added_again(self) -> None:
        """The generated tag must not be appended when aliases already hold it."""
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        node = MagicMock()
        node.external_id = "pi:160035"
        node.properties = {self.view_id: {"name": "VAL_23-KA-9101", "aliases": ["23-KA-9101"]}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_a_name_that_yields_its_existing_alias_does_not_gain_the_name(self) -> None:
        """The steady state: the pattern matched, and its alias is already stored.

        Nothing was extracted *anew*, but the fallback must not read that as a failure
        and append the whole name on every run.
        """
        processor = OptimizedMetadataProcessor(
            self.logger, timeseries_alias_rule=AliasRule.from_config([DEFAULT_ALIAS_PATTERN])
        )
        node = MagicMock()
        node.external_id = "pi:160032"
        node.properties = {self.view_id: {"name": "VAL_23-KA-9101", "aliases": ["23-KA-9101"]}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_each_view_uses_its_own_pattern(self) -> None:
        """The asset pattern must not be applied to timeseries names, or the reverse."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]),
            asset_alias_rule=AliasRule.from_config([r"(\d{2})[-_]([A-Z]{2,3})"]),
        )
        asset_view = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {asset_view: {"name": "23-KA pump", "aliases": [], "tags": []}}

        result = processor.process_asset_metadata(node, asset_view, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA"])

    def test_update_all_rebuilds_only_aliases_the_configured_pattern_generates(self) -> None:
        """Managed aliases follow the configured pattern, not the built-in default shape."""
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))
        node = MagicMock()
        node.external_id = "pi:160011"
        node.properties = {
            self.view_id: {
                "name": "PMP1234 discharge pressure",
                # The first is what this pattern generates and is rebuilt; the second is
                # the default pattern's shape, which is now someone else's data.
                "aliases": ["PMP-1234", "23-KA-9101"],
            }
        }

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101", "PMP-1234"])

    def test_a_stale_generated_alias_is_dropped_when_the_name_changes(self) -> None:
        """The point of rebuilding: an alias from a previous name must not linger.

        This is why a pattern has to tolerate "-" between its groups - that is the
        separator the generated alias uses, and how the function recognises its own work.
        """
        processor = OptimizedMetadataProcessor(self.logger, timeseries_alias_rule=AliasRule.from_config([PUMP_PATTERN]))
        node = MagicMock()
        node.external_id = "pi:160012"
        node.properties = {self.view_id: {"name": "PMP9999 discharge pressure", "aliases": ["PMP-1234"]}}

        result = processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertEqual(result.sources[0].properties["aliases"], ["PMP-9999"])

    def test_file_aliases_cover_the_name_without_extension_and_the_tag(self) -> None:
        """A document is findable both by its bare file name and by the tag it carries."""
        node = MagicMock()
        node.external_id = "file:4001"
        node.properties = {self.file_view_id: {"name": "PID_23-KA-9101_rev3.pdf", "aliases": []}}

        result = self.processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(
            result.sources[0].properties["aliases"],
            ["PID-23-KA-9101-rev3", "23-KA-9101"],
        )

    def test_a_file_name_without_an_extension_is_used_as_is(self) -> None:
        """Nothing to strip, so the name itself becomes the alias."""
        node = MagicMock()
        node.external_id = "file:4002"
        node.properties = {self.file_view_id: {"name": "23-KA-9101", "aliases": []}}

        result = self.processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101"])

    def test_files_use_their_own_configured_pattern(self) -> None:
        """Documents may be named on a different convention than the assets they describe."""
        processor = OptimizedMetadataProcessor(
            self.logger,
            asset_alias_rule=AliasRule.from_config([r"(\d{2})[-_]([A-Z]{2,3})"]),
            file_alias_rule=AliasRule.from_config([PUMP_PATTERN]),
        )
        node = MagicMock()
        node.external_id = "file:4003"
        node.properties = {self.file_view_id: {"name": "PMP1234_datasheet.pdf", "aliases": []}}

        result = processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(result.sources[0].properties["aliases"], ["PMP1234-datasheet", "PMP-1234"])

    def test_file_without_a_pattern_match_does_not_use_the_name_as_an_alias(self) -> None:
        """A descriptive file name is not a tag; it must not be rewritten into aliases."""
        node = MagicMock()
        node.external_id = "file:4021"
        node.properties = {
            self.file_view_id: {
                "name": "23-1ST STAGE COMP ENCLOSURE-PH.pdf",
                "aliases": ["23-1ST STAGE COMP ENCLOSURE-PH"],
            }
        }

        result = self.processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNotNone(result)
        self.assertIsNone(result.sources[0].properties["aliases"])

    def test_document_number_aliases_are_normalized(self) -> None:
        """Document numbers get the same separator rewrite as equipment tags."""
        processor = OptimizedMetadataProcessor(self.logger, file_alias_rule=AliasRule.from_config(DOCUMENT_PATTERNS))
        node = MagicMock()
        node.external_id = "file:4010"
        node.properties = {self.file_view_id: {"name": "PH-25578-P-4110006-001.pdf", "aliases": []}}

        result = processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertEqual(
            result.sources[0].properties["aliases"],
            ["PH-25578-P-4110006-001", "PH-25578-P-4110006"],
        )

    def test_a_document_alias_without_its_sheet_number_is_still_ours(self) -> None:
        """The sheet number sits outside the group, so the short alias must round-trip.

        Without that, updateAll would treat the alias it just wrote as hand-curated.
        """
        rule = AliasRule.from_config(DOCUMENT_PATTERNS)

        self.assertEqual(
            _unmanaged_aliases(["PH-25578-P-4110006", "PH_25578_P_4110006", "operator note"], rule),
            ["operator note"],
        )

    def test_a_longer_prefix_does_not_yield_a_truncated_document_alias(self) -> None:
        """Matching from the second letter of a prefix would write a wrong document number."""
        processor = OptimizedMetadataProcessor(self.logger, file_alias_rule=AliasRule.from_config(DOCUMENT_PATTERNS))
        node = MagicMock()
        node.external_id = "file:4011"
        node.properties = {self.file_view_id: {"name": "SHEET-1-A-2.pdf", "aliases": []}}

        result = processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas", update_all=True)

        # No pattern match and no existing aliases → nothing to write.
        self.assertIsNone(result)

    def test_file_skips_update_when_aliases_already_present(self) -> None:
        """No write when there is nothing to add, so reruns stay cheap."""
        node = MagicMock()
        node.external_id = "file:4004"
        node.properties = {
            self.file_view_id: {
                "name": "PID_23-KA-9101_rev3.pdf",
                "aliases": ["PID-23-KA-9101-rev3", "23-KA-9101"],
            }
        }

        result = self.processor.process_file_metadata(node, self.file_view_id, "inst_cfihos_oil_and_gas")

        self.assertIsNone(result)

    def test_file_update_all_rebuilds_generated_aliases_and_keeps_curated_ones(self) -> None:
        """A tag alias left over from a previous name is replaced, a curated note is not."""
        node = MagicMock()
        node.external_id = "file:4005"
        node.properties = {
            self.file_view_id: {
                "name": "PID_23-KA-9101_rev3.pdf",
                "aliases": ["manual note", "23_AB_0001"],
            }
        }

        result = self.processor.process_file_metadata(
            node, self.file_view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertEqual(
            result.sources[0].properties["aliases"],
            ["manual note", "PID-23-KA-9101-rev3", "23-KA-9101"],
        )

    def test_timeseries_skips_update_when_aliases_unchanged(self) -> None:
        """Test timeseries processing skips DM update when aliases already match"""
        print("🧪 Testing timeseries skip unchanged aliases...")

        node = MagicMock()
        node.external_id = "pi:160002"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                "aliases": ["existing", "23-KA-9101"],
            }
        }

        result = self.processor.process_timeseries_metadata(node, self.view_id, "inst_cfihos_oil_and_gas")
        self.assertIsNone(result)

        print("✅ Timeseries skip unchanged aliases test passed")

    def test_timeseries_update_all_replaces_stale_managed_alias(self) -> None:
        """Test updateAll drops a managed alias left over from an earlier name"""
        print("🧪 Testing timeseries updateAll...")

        node = MagicMock()
        node.external_id = "pi:160003"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                "aliases": ["11-PT-2222", "23-KA-9101"],
            }
        }

        result = self.processor.process_timeseries_metadata(
            node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertIsNotNone(result)
        properties = result.sources[0].properties
        self.assertEqual(properties["aliases"], ["23-KA-9101"])

        print("✅ Timeseries updateAll test passed")

    def test_timeseries_update_all_keeps_unmanaged_aliases(self) -> None:
        """Test updateAll leaves aliases this function never generated in place"""
        print("🧪 Testing timeseries updateAll keeps unmanaged aliases...")

        node = MagicMock()
        node.external_id = "pi:160005"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                # Curated by hand: the second one embeds a tag pattern but is not a
                # value this function would ever have written.
                "aliases": ["operator note", "spare for 23-AB-1234"],
            }
        }

        result = self.processor.process_timeseries_metadata(
            node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertIsNotNone(result)
        self.assertEqual(
            result.sources[0].properties["aliases"],
            ["operator note", "spare for 23-AB-1234", "23-KA-9101"],
        )

        print("✅ Timeseries updateAll unmanaged alias test passed")

    def test_remove_old_aliases_drops_hand_curated_aliases(self) -> None:
        """removeOldAliases replaces the whole list, unlike updateAll."""
        node = MagicMock()
        node.external_id = "pi:160006"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                "aliases": ["operator note", "spare for 23-AB-1234", "23-KA-9101"],
            }
        }

        result = self.processor.process_timeseries_metadata(
            node,
            self.view_id,
            "inst_cfihos_oil_and_gas",
            remove_old_aliases=True,
        )

        self.assertIsNotNone(result)
        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101"])

    def test_remove_old_aliases_skips_update_when_output_already_matches(self) -> None:
        """No write when the produced aliases already equal what is stored."""
        node = MagicMock()
        node.external_id = "pi:160007"
        node.properties = {self.view_id: {"name": "VAL_23-KA-9101:X.Value", "aliases": ["23-KA-9101"]}}

        result = self.processor.process_timeseries_metadata(
            node,
            self.view_id,
            "inst_cfihos_oil_and_gas",
            remove_old_aliases=True,
        )

        self.assertIsNone(result)

    def test_remove_old_aliases_clears_the_property_when_no_alias_is_produced(self) -> None:
        """Nothing produced must reach CDF as null, otherwise the old aliases survive."""
        node = MagicMock()
        node.external_id = "pi:160008"
        node.properties = {self.view_id: {"name": "Reactor outlet temperature", "aliases": ["operator note"]}}

        result = self.processor.process_timeseries_metadata(
            node,
            self.view_id,
            "inst_cfihos_oil_and_gas",
            remove_old_aliases=True,
        )

        self.assertIsNotNone(result)
        self.assertIsNone(result.sources[0].properties["aliases"])

    def test_timeseries_update_all_applies_even_when_aliases_already_correct(self) -> None:
        """updateAll does not write when the rebuilt aliases already match storage."""
        print("🧪 Testing timeseries updateAll skip when unchanged...")

        node = MagicMock()
        node.external_id = "pi:160004"
        node.properties = {
            self.view_id: {
                "name": "VAL_23-KA-9101:X.Value",
                "aliases": ["23-KA-9101"],
            }
        }

        result = self.processor.process_timeseries_metadata(
            node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertIsNone(result)

        print("✅ Timeseries updateAll skip-when-unchanged test passed")

    def test_asset_update_all_replaces_stale_managed_alias(self) -> None:
        """Test updateAll drops managed aliases but keeps unmanaged ones"""
        print("🧪 Testing asset updateAll...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {
            asset_view_id: {
                "name": "23-KA-9101",
                "aliases": ["operator note", "11-PT-2222", "spare for 23-AB-1234"],
                "tags": ["discipline:KA", "tag", "root:old_root"],
                "root": {"space": "inst_cfihos_oil_and_gas", "externalId": "VAL-PH"},
            }
        }

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertIsNotNone(result)
        properties = result.sources[0].properties
        self.assertEqual(
            properties["aliases"],
            ["operator note", "spare for 23-AB-1234", "23-KA-9101"],
        )
        self.assertNotIn("tags", properties)

        print("✅ Asset updateAll test passed")

    def test_asset_update_all_applies_even_when_metadata_already_correct(self) -> None:
        """updateAll does not write when the rebuilt aliases already match storage."""
        print("🧪 Testing asset updateAll skip when unchanged...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {
            asset_view_id: {
                "name": "23-KA-9101",
                "aliases": ["23-KA-9101"],
                "tags": ["discipline:KA", "root:VAL-PH"],
                "root": {"space": "inst_cfihos_oil_and_gas", "externalId": "VAL-PH"},
            }
        }

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertIsNone(result)

        print("✅ Asset updateAll skip-when-unchanged test passed")

    def test_asset_incremental_adds_missing_alias(self) -> None:
        """Test incremental asset processing adds the alias its name yields"""
        print("🧪 Testing asset incremental alias...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {
            asset_view_id: {
                "name": "23-KA-9101",
                "aliases": [],
                "root": {"space": "inst_cfihos_oil_and_gas", "externalId": "VAL-PH"},
            }
        }

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=False)

        self.assertIsNotNone(result)
        self.assertEqual(result.sources[0].properties["aliases"], ["23-KA-9101"])

        print("✅ Asset incremental alias test passed")

    def test_asset_tags_are_never_written(self) -> None:
        """This function manages aliases only, so tags stay exactly as the site set them.

        Writing a tag property the configured view does not have is rejected for the
        whole batch, so the safe thing is to touch none of them.
        """
        print("🧪 Testing asset tags left untouched...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {
            asset_view_id: {
                "name": "23-KA-9101",
                "aliases": [],
                "tags": ["discipline:KA", "root:OLD-PH"],
                "root": {"space": "inst_cfihos_oil_and_gas", "externalId": "VAL-PH"},
            }
        }

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=False)

        self.assertIsNotNone(result)
        self.assertEqual(list(result.sources[0].properties), ["aliases"])

        print("✅ Asset tags untouched test passed")

    def test_asset_incremental_skips_update_when_aliases_already_complete(self) -> None:
        """Test incremental asset processing writes nothing when the alias is present"""
        print("🧪 Testing asset incremental no-op...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {
            asset_view_id: {
                "name": "23-KA-9101",
                "aliases": ["23-KA-9101"],
                "tags": ["root:VAL-PH", "discipline:KA"],
                "root": {"space": "inst_cfihos_oil_and_gas", "externalId": "VAL-PH"},
            }
        }

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=False)

        self.assertIsNone(result)

        print("✅ Asset incremental no-op test passed")

    def test_asset_update_all_skips_node_without_view_properties(self) -> None:
        """updateAll must not blank managed properties when the view payload is empty"""
        print("🧪 Testing asset skip on empty view properties...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        other_view_id = ViewId(space="cdf_cdm", external_id="CogniteDescribable", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = {other_view_id: {"name": "23-KA-9101"}}

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertIsNone(result)

        print("✅ Asset skip on empty view properties test passed")

    def test_timeseries_update_all_skips_node_without_view_properties(self) -> None:
        """updateAll must not blank managed properties when the view payload is empty"""
        print("🧪 Testing timeseries skip on empty view properties...")

        node = MagicMock()
        node.external_id = "pi:160005"
        node.properties = {self.view_id: {}}

        result = self.processor.process_timeseries_metadata(
            node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertIsNone(result)

        print("✅ Timeseries skip on empty view properties test passed")

    def test_asset_skips_node_with_none_properties(self) -> None:
        """Nodes with no properties populated must be skipped safely"""
        print("🧪 Testing asset skip on None properties...")

        asset_view_id = ViewId(space="cdf_cdm", external_id="CogniteAsset", version="v1")
        node = MagicMock()
        node.external_id = "23-KA-9101"
        node.properties = None

        result = self.processor.process_asset_metadata(node, asset_view_id, "inst_cfihos_oil_and_gas", update_all=True)

        self.assertIsNone(result)

        print("✅ Asset skip on None properties test passed")

    def test_timeseries_skips_node_with_none_properties(self) -> None:
        """Nodes with no properties populated must be skipped safely"""
        print("🧪 Testing timeseries skip on None properties...")

        node = MagicMock()
        node.external_id = "pi:160005"
        node.properties = None

        result = self.processor.process_timeseries_metadata(
            node, self.view_id, "inst_cfihos_oil_and_gas", update_all=True
        )

        self.assertIsNone(result)

        print("✅ Timeseries skip on None properties test passed")

    def test_alias_generation_caching(self) -> None:
        """Test alias generation with caching"""
        print("🧪 Testing alias generation caching...")

        tag = "VAL_23-KA-9101:X.Value"

        # Test timeseries alias generation
        aliases1 = self.processor._get_timeseries_alias_list_optimized(tag, ("existing",))
        aliases2 = self.processor._get_timeseries_alias_list_optimized(tag, ("existing",))  # Should use cache

        self.assertEqual(aliases1, aliases2)
        self.assertIn("existing", aliases1)
        self.assertIn("23-KA-9101", aliases1)

        # Test asset alias generation
        asset_aliases = self.processor._get_asset_alias_list_optimized("23-KA-9101", ("existing",))
        self.assertIn("existing", asset_aliases)
        self.assertIn("23-KA-9101", asset_aliases)

        print("✅ Alias generation caching test passed")

    def test_processing_statistics(self) -> None:
        """Test processing statistics collection"""
        print("🧪 Testing processing statistics...")

        # Mock some processing
        self.processor.stats["processed"] = 100
        self.processor.stats["updated"] = 75

        stats = self.processor.get_stats()

        self.assertEqual(stats["processed"], 100)
        self.assertEqual(stats["updated"], 75)
        self.assertEqual(stats["update_rate"], 0.75)

        print("✅ Processing statistics test passed")


class TestIntegrationScenarios(unittest.TestCase):
    """Test integration scenarios and real-world usage patterns"""

    def setUp(self) -> None:
        self.logger = CogniteFunctionLogger("DEBUG")

    def test_large_dataset_simulation(self) -> None:
        """Test optimization performance with simulated large dataset"""
        print("🧪 Testing large dataset simulation...")

        processor = OptimizedMetadataProcessor(self.logger)

        # Simulate processing many items
        start_time = time.time()

        for i in range(1000):
            # Test cached operations
            aliases = processor._get_timeseries_alias_list_optimized(
                f"test-item-{i % 10}",
                ("existing",),  # Reuse names to test caching
            )
            self.assertIsInstance(aliases, tuple)

        end_time = time.time()
        processing_time = end_time - start_time

        print(f"   Processed 1000 items in {processing_time:.3f}s")
        self.assertLess(processing_time, 1.0)  # Should be very fast due to caching

        print("✅ Large dataset simulation test passed")


if __name__ == "__main__":
    unittest.main()
