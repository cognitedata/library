"""
Optimized Metadata Update Handler

This handler provides optimized metadata update functionality with enhanced
performance monitoring, error handling, and logging as the default implementation.
"""

import os
import sys
from pathlib import Path
from typing import Any

from cognite.client import ClientConfig, CogniteClient
from cognite.client.credentials import OAuthClientCredentials

sys.path.append(str(Path(__file__).parent))

from config import load_config_parameters
from logger import CogniteFunctionLogger
from metadata_optimizations import (
    PerformanceBenchmark,
    cleanup_memory,
    monitor_memory_usage,
    optimize_metadata_processing,
    time_operation,
)
from pipeline import metadata_update

# ---------------------------------------------------------------------------
# Usage tracking
# ---------------------------------------------------------------------------
_SOURCE = "dp:contextualization:cdf_entity_matching"
_DP_VERSION = "1"
_TRACKER_VERSION = "1"


def _report_usage(client: CogniteClient) -> None:
    try:
        import threading

        from mixpanel import Consumer, Mixpanel
        mp = Mixpanel("8f28374a6614237dd49877a0d27daa78", consumer=Consumer(api_host="api-eu.mixpanel.com"))
        distinct_id = f"{client.config.project}:{client.config.cdf_cluster}"
        def _send() -> None:
            mp.track(distinct_id, "fn-handle", {
                "source": _SOURCE,
                "tracker_version": _TRACKER_VERSION,
                "dp_version": _DP_VERSION,
                "type": "py-function",
                "cdf_cluster": client.config.cdf_cluster,
                "cdf_project": client.config.project,
            })
        threading.Thread(target=_send, daemon=False).start()
    except Exception:
        # Usage tracking is best-effort; must not affect the handler.
        pass


def handle(data: dict[str, Any], client: CogniteClient) -> dict[str, Any]:
    """
    Optimized metadata update handler with enhanced performance and monitoring.
    
    This is now the default implementation, providing all optimizations automatically.
    
    Args:
        data: Function data containing extraction pipeline configuration
        client: Authenticated CogniteClient instance
        
    Returns:
        Dict containing status and result information
    """
    _report_usage(client)
    logger = None
    benchmark = None
    
    try:
        # Apply global optimizations
        optimize_metadata_processing()
        
        # Initialize enhanced logging and monitoring
        loglevel = data.get("logLevel", "INFO")
        logger = CogniteFunctionLogger(loglevel)
        benchmark = PerformanceBenchmark(logger)
        
        logger.info(f"🚀 Starting OPTIMIZED metadata update with loglevel = {loglevel}")
        logger.info(f"📝 Reading parameters from extraction pipeline config: {data.get('ExtractionPipelineExtId')}")
        
        # Monitor initial memory usage
        monitor_memory_usage(logger, "Handler start")
        
        # Load configuration with timing
        config = benchmark.benchmark_function(
            "Configuration loading",
            load_config_parameters,
            client, data
        )
        logger.debug("✅ Configuration loaded successfully")
        
        # Execute optimized metadata update pipeline
        with time_operation("Complete metadata update pipeline", logger):
            benchmark.benchmark_function(
                "Metadata update pipeline",
                metadata_update,
                client, logger, data, config
            )
        
        # Final cleanup and monitoring
        cleanup_memory()
        monitor_memory_usage(logger, "Handler end")
        
        # Log performance summary
        if benchmark:
            benchmark.log_summary()
        
        logger.info("🎉 Optimized metadata update completed successfully!")
        return {"status": "succeeded", "data": data}
        
    except Exception as e:
        message = f"Optimized metadata update failed: {e!s}"
        
        if logger:
            logger.error(message)
            if benchmark:
                benchmark.log_summary()
        else:
            print(f"[ERROR] {message}")
        
        return {"status": "failure", "message": message}


def run_locally():
    """
    Run the optimized metadata update locally with enhanced error handling.
    """
    
    print("🚀 Optimized Metadata Update Pipeline")
    print("=" * 50)
    
    try:
        # Apply optimizations
        optimize_metadata_processing()
        
        # Validate environment variables
        required_envvars = ("CDF_PROJECT", "CDF_CLUSTER", "IDP_CLIENT_ID", "IDP_CLIENT_SECRET", "IDP_TOKEN_URL")
        if missing := [envvar for envvar in required_envvars if envvar not in os.environ]:
            raise ValueError(f"Missing required environment variables: {missing}")
        
        # Extract configuration
        cdf_project_name = os.environ["CDF_PROJECT"]
        cdf_cluster = os.environ["CDF_CLUSTER"]
        client_id = os.environ["IDP_CLIENT_ID"]
        client_secret = os.environ["IDP_CLIENT_SECRET"]
        token_uri = os.environ["IDP_TOKEN_URL"]
        base_url = f"https://{cdf_cluster}.cognitedata.com"
        
        # Initialize client
        client = CogniteClient(
            ClientConfig(
                client_name="Optimized Metadata Update Pipeline",
                base_url=base_url,
                project=cdf_project_name,
                credentials=OAuthClientCredentials(
                    token_url=token_uri,
                    client_id=client_id,
                    client_secret=client_secret,
                    scopes=[f"{base_url}/.default"],
                ),
            )
        )
        
        # Test data
        data = {
            "logLevel": "INFO",
            "ExtractionPipelineExtId": "ep_ctx_entity_matching_metadata_update"
        }
        
        print("🔄 Starting optimized metadata update...")
        result = handle(data, client)
        
        if result["status"] == "succeeded":
            print("✅ Optimized metadata update completed successfully!")
        else:
            print(f"❌ Metadata update failed: {result.get('message', 'Unknown error')}")
        
        return result
        
    except Exception as e:
        print(f"❌ Failed to run metadata update: {e}")
        import traceback
        traceback.print_exc()
        return {"status": "failure", "message": str(e)}


if __name__ == "__main__":
    result = run_locally()
    print(f"\n📊 Final result: {result}")
