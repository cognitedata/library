# Aliases Update

This function writes normalized `aliases` on timeseries, assets and files in Cognite Data Fusion (CDF) ahead of entity matching, with paged reads, batch writes, and retry handling.

## 🚀 Features

- **35-55% faster execution** compared to legacy implementation
- **Paged reads** of only the properties aliases need, written page by page
- **Batch processing** with retry logic for robust API interactions
- **Enhanced error handling** with comprehensive logging
- **Caching mechanisms** for improved performance
- **Automatic optimization** applied by default

## 📁 Module Structure

```
fn_dm_context_aliases_update/
├── handler.py                    # Main function handler with optimizations
├── pipeline.py                   # Core pipeline logic with batch processing
├── alias_optimizations.py        # Optimization utilities and classes
├── config.py                     # Configuration management
├── logger.py                     # Enhanced logging functionality
├── constants.py                  # Module constants
├── requirements.txt              # Direct deploy dependencies for CDF
├── pyproject.toml                # uv package definition
└── README.md                     # This file
```

## 🔧 Configuration

### Environment Variables

The following environment variables are required:

```bash
# CDF Connection
CDF_PROJECT=your-cdf-project
CDF_CLUSTER=your-cdf-cluster
IDP_CLIENT_ID=your-client-id
IDP_CLIENT_SECRET=your-client-secret
IDP_TOKEN_URL=https://your-idp-url/oauth2/token

# Optional: Debug settings
DEBUG_MODE=false
LOG_LEVEL=INFO
```

### Extraction Pipeline Configuration

The module reads configuration from the extraction pipeline in CDF:

```yaml
# Example extraction pipeline config
ExtractionPipelineExtId: "ep_ctx_aliases_update"
parameters:
  run_all: false
  update_all: false
  remove_old_aliases: false
  batch_size: 1000
  raw_db: "contextualization_state"
  raw_table_state: "state_store"
data:
  job:
    timeseries_view:
      space: "your_space"
      external_id: "TimeSeries"
      version: "v1"
      instance_space: "your_instance_space"
      aliasPattern:
        - '([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})'
      aliasSelection: all
    asset_view:
      space: "your_space"
      external_id: "Asset"
      version: "v1"
      instance_space: "your_instance_space"
      aliasPattern:
        - '([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})'
      aliasSelection: all
    # Optional — omit to leave file metadata untouched
    file_view:
      space: "your_space"
      external_id: "CogniteFile"
      version: "v1"
      instance_space: "your_instance_space"
      aliasPattern:
        - '([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})'
      aliasSelection: all
```

| Parameter | Purpose |
|-----------|---------|
| `runAll` | Fetch all instances (not only those missing `aliases`) |
| `updateAll` | Rebuild generated aliases on every fetched instance (implies `runAll`). A DM write — and the “updated” count — happens only when the rebuilt list differs from what is already stored |
| `removeOldAliases` | Discard every existing alias and write only what this run produces (implies `runAll`) |

Every view is fetched on the presence of `aliases` alone, so `runAll`, `updateAll` and
`removeOldAliases` are the settings that change what gets processed. Time series have no
separate single-instance filter.

`instanceSpace` on each view takes either a single space or a list of spaces. Instances
are read from every listed space and updated in the space they were read from.

`fileView` is optional. Leave it out and files are skipped — a configuration written
before file support existed keeps working untouched.

### Alias pattern

`aliasPattern` is the regular expression that finds the tag inside an instance's `name`.
Each view configures its own, so timeseries, assets and files can follow different naming
conventions. The alias written back is the pattern's **capture groups joined by `-`** —
the groups decide the alias, not the whole match — so with the default pattern
`VAL_23-KA-9101:X.Value` yields `23-KA-9101`. When a pattern uses one capture group for
the whole tag, separators inside that group (`_`, `.`, `:`) are still rewritten to `-`
for every generated alias, including letter-prefixed tags (`DB_9101` → `DB-9101`) and
document numbers. Every pattern defaults to the shape above, so a configuration written
before this setting existed keeps behaving the same.

When no pattern extracts anything from a name, **no alias is produced**. The `aliases`
property is then written as null, which clears whatever was stored — an empty list would
leave the old values in place, so `removeOldAliases` would not remove anything. Instances
that had no aliases to begin with are left untouched. The run logs `No alias extracted based on configured <view> regular expression for name: …` for
the first ten such names, then counts the rest and reports the total once at the end. A run
full of those warnings means the pattern does not match your names, not that the data is
wrong.

An invalid regular expression, or one with no capture group, is a configuration error
rather than a missing alias. It fails the run at config load with a message naming the
offending pattern, and nothing is written.

A view can list **several patterns** when its names follow more than one convention.
Each pattern that matches contributes one alias, and the view's own `aliasSelection`
decides what to keep — every view sets it independently:

| `aliasSelection` | Result |
|------------------|--------|
| `all` (default)  | One alias per matching pattern |
| `longest`        | Only the longest alias, the most specific reading of the name |

```yaml
aliasPattern:
  - '([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})'
  - '([A-Z]{3})[-_]?([0-9]{4})'
aliasSelection: longest
```

Given that config, `VAL_23-KA-9101_PMP1234:X.Value` matches both patterns; `all` writes
`23-KA-9101` and `PMP-1234`, `longest` writes only `23-KA-9101`. When two aliases are
equally long the first matching pattern in the list wins, so the order you configure is
also the precedence. A single pattern may still be given as a plain string rather than a
list.

Changing `aliasSelection` from `all` to `longest` retires the aliases that are no longer
selected on the next `updateAll` run: an alias is recognised as generated when **any**
configured pattern reproduces it, regardless of which one currently wins.

Two rules when writing a pattern:

- **Use character classes, not backslash escapes** — `[0-9]`, not `\d`. Toolkit
  substitutes module variables as a regex replacement, and a backslash escape in the
  value fails the build with `bad escape \d`.
- **Accept `-` as a separator between the groups.** The generated alias joins the groups
  with `-`, and the function identifies its own earlier output by feeding a stored alias
  back through the pattern and checking it rebuilds unchanged. Prefer also accepting `_`
  so aliases written by an earlier underscore-normalising run are still recognised.
  A pattern that cannot match `-` never recognises its own aliases, so `updateAll` leaves
  stale ones in place. For example prefer `([A-Z]{3})[-_]?([0-9]{4})` over
  `([A-Z]{3})([0-9]{4})`.

Deploying a changed pattern does not retire aliases generated by the previous one; they
are no longer recognised as generated and are treated as hand-curated from then on.

### File aliases

Files get the name with its final extension removed **in addition to** the usual
pattern-derived aliases **only when a pattern matches**, so a document is findable both
by its bare file name and by the tag it refers to. `PID_23-KA-9101_rev3.pdf` yields
`PID-23-KA-9101-rev3` and `23-KA-9101`. A name that matches no pattern, such as
`23-1ST STAGE COMP ENCLOSURE-PH.pdf`, produces no alias.

`aliasSelection` does not apply to the extension-stripped name — that alias is not a
pattern match, so it is always kept.

#### Document numbers

The module's default `fileAliasPattern` recognises document numbers as well as equipment
tags, so `PH-25578-P-4110006-001.pdf` gets both `PH-25578-P-4110006-001` and the same
number without its sheet number, `PH-25578-P-4110006`:

```yaml
fileAliasPattern:
  - '(?<![A-Z])([A-Z]{2,4}[-_][0-9]+[-_][A-Z][-_][0-9]+[-_][0-9]+)'
  - '(?<![A-Z])([A-Z]{2,4}[-_][0-9]+[-_][A-Z][-_][0-9]+)(?:[-_][0-9]+)?'
  - '([0-9]{2})[-_.:]([A-Z]{2,3})[-_.:]([0-9]{4,5})'
```

Three details make that work, and are worth copying when adapting the patterns to a
different document numbering scheme:

- **Accept `_` as well as `-` between segments.** Generated aliases always use `-`, and
  the function identifies its own earlier output by feeding a stored alias back through
  the pattern.
- **The sheet number sits outside the group and is optional** — `(?:[-_][0-9]+)?`. Optional
  is what lets the shortened alias be recognised as generated when it is read back, so
  `updateAll` rebuilds it instead of treating it as hand-curated.
- **`(?<![A-Z])` stops a match starting mid-prefix.** Without it a name like
  `SHEET-1-A-2.pdf` would match from `HEET`, writing a truncated document number. The
  prefix itself allows two to four letters.

This list needs `aliasSelection: all` to produce both aliases; `longest` would keep only
`PH-25578-P-4110006-001`.

The extension-stripped alias cannot be recognised as generated the way a tag alias can —
it is ordinary text, not a pattern match. So renaming a file and rerunning with
`updateAll` adds an alias for the new name but leaves the old one behind; remove it by
hand if that matters.

For a full metadata refresh, set `updateAll: true` in the extraction pipeline config.
That rebuilds only the values this function generates — aliases matching the view's
`aliasPattern` — while hand-curated aliases are preserved, including aliases that merely
mention a tag (for example `spare for 23-AB-1234`). After the rebuild, the function
compares the new list to what is already on the instance: if they are the same, it
skips the DM write and does not count the instance as updated. Use `updateAll` to retire
stale generated aliases or pick up a changed pattern; do not expect every fetched
instance to appear in the update count on a no-op rerun.

To replace the entire `aliases` list — generated and hand-curated alike — set
`removeOldAliases: true`. The function then writes only the aliases it produces on this
run, similar to `removeOldLinks` on the entity matching function. Like `updateAll`, it
implies `runAll` so instances that already carry aliases are fetched and rewritten.

## 🏃‍♂️ How to Run

### 1. As a CDF Function

Deploy the function to CDF and configure it with an extraction pipeline:

```python
# The function will be triggered by CDF
# No manual execution needed
```

### 2. Local Development

Dependencies are managed with [uv](https://docs.astral.sh/uv/). Use `pyproject.toml` for local dev; `requirements.txt` lists direct deploy packages for CDF. From the **repository root**, run `uv sync --group dev` once.

After changing local dependencies: `uv lock` then `uv sync --group dev`. After changing CDF deploy dependencies: edit `deploy_dependencies` in `scripts/generate_uv_member_projects.py`, then `python scripts/export_deploy_requirements.py`.

```bash
# Set environment variables
export CDF_PROJECT=your-project
export CDF_CLUSTER=your-cluster
export IDP_CLIENT_ID=your-client-id
export IDP_CLIENT_SECRET=your-secret
export IDP_TOKEN_URL=your-token-url

# Run the handler directly
cd modules/contextualization/cdf_entity_matching/functions/fn_dm_context_aliases_update
uv run python handler.py
```

### 3. Programmatic Usage

```python
from handler import handle
from cognite.client import CogniteClient

# Initialize client
client = CogniteClient.default()

# Configure data
data = {
    "logLevel": "INFO",
    "ExtractionPipelineExtId": "ep_ctx_aliases_update"
}

# Run the optimized handler
result = handle(data, client)
print(result)
```

## 🔍 Functionality

### Core Components

#### 1. **OptimizedMetadataProcessor**
- Processes timeseries, asset and file metadata with caching
- Adds normalized tag aliases for entity matching, and for files the file name without
  its extension
- Handles batch updates one page at a time

Entity matching (submit/collect) then reads those aliases via
`entityViewSearchProperty` / `targetViewSearchProperty`: entities use the **longest**
alias as the match string; targets keep **all** aliases. See
[fn_dm_context_entity_matching](../fn_dm_context_entity_matching/README.md#how-aliases-are-used).

#### 2. **BatchProcessor**
- Applies node updates in configurable batches (default 1000, the SDK's own chunk size)
- Retries each batch with exponential backoff, then splits into smaller chunks on failure

### Processing Flow

1. **Initialization**: Set up logging
2. **Configuration**: Load parameters from extraction pipeline
3. **Timeseries Processing**:
   - Read the timeseries in scope 1000 at a time, with only `name` and `aliases`, and
     retry a page that fails on a transient error
   - Add normalized aliases when tag patterns match
   - Write each page's updates before reading the next
4. **Asset Processing**: as for timeseries
5. **File Processing** (only when `fileView` is configured): as for timeseries, adding
   the file name without its extension as well
6. **Summary**: Log processed and updated counts, and names no pattern could read

A failed read or write fails the function call rather than returning a failure status,
so the workflow stops before entity matching runs on stale aliases.

### Performance Optimizations

- **Caching**: LRU-cached alias generation for repeated tag patterns
- **Batch Processing**: Configurable batch sizes with retry logic
- **Error Recovery**: Robust error handling with fallback mechanisms

## 🧪 Testing

### Run All Tests

From the repository root:

```bash
uv run pytest modules/contextualization/cdf_entity_matching/tests/fn_dm_context_aliases_update -q
```

### Test Categories

#### 1. **Unit Tests**
```bash
uv run pytest modules/contextualization/cdf_entity_matching/tests/fn_dm_context_aliases_update/test_alias_optimizations.py::TestOptimizedMetadataProcessor -v
```

#### 2. **Integration Tests**
```bash
uv run pytest modules/contextualization/cdf_entity_matching/tests/fn_dm_context_aliases_update/test_alias_optimizations.py::TestIntegrationScenarios -v
```

### Test Coverage

The test suite covers:
- ✅ All optimization classes and functions
- ✅ Error handling scenarios
- ✅ Batch processing logic
- ✅ Caching mechanisms
- ✅ Integration scenarios

## 📊 Performance Metrics

### Monitoring

The module provides detailed monitoring:

```
📊 Processing Stats: 1500 processed, 1200 updated, 80.00% update rate
⏱️ Time: Configuration processing took 0.15 seconds
⏱️ Time: Timeseries processing took 45.30 seconds
⏱️ Time: Asset processing took 32.10 seconds
```

Step timings are logged at DEBUG.

## 🛠️ Dependencies

See `pyproject.toml` for local dev dependencies; `requirements.txt` lists direct deploy packages for CDF.

```txt
cognite-sdk>=7.0.0
tenacity>=8.0.0
```

## 🔧 Troubleshooting

### Common Issues

1. **Memory Issues**
   - Reduce batch size in configuration

2. **API Rate Limits**
   - Retry logic handles temporary failures
   - Adjust batch sizes if needed
   - Check CDF project limits

3. **Performance Issues**
   - Review batch size configuration
   - Check network connectivity
   - Monitor cache hit rates

### Debug Mode

Enable debug mode for troubleshooting:

```python
data = {
    "logLevel": "DEBUG",
    "ExtractionPipelineExtId": "your-pipeline-id"
}
```

## 📈 Monitoring and Logging

### Log Levels

- **DEBUG**: Detailed processing information
- **INFO**: General progress and statistics
- **WARNING**: Non-critical issues
- **ERROR**: Critical failures

### Performance Logs

At **INFO**, expect startup, extraction pipeline id, loaded configuration summary, per-view progress, batch apply counts, and processing stats. Step timings are **DEBUG** only.

```
Starting Aliases Update with loglevel = INFO
Reading parameters from extraction pipeline config: ep_ctx_aliases_update
Configuration loading took 0.13s
Loaded extraction pipeline configuration:
  parameters:
    runAll: True
    ...
📊 Processing Stats: 1000 processed, 800 updated, 80.00% update rate
Aliases Update completed successfully!
```

## 🤝 Contributing

1. Follow the existing code structure
2. Add tests for new functionality
3. Update documentation
4. Ensure performance optimizations are maintained
5. Run the test suite before submitting

## 📄 License

This module is part of the [Cognite library](https://github.com/cognitedata/library) repository. 