import json
import re
import sys
import traceback
from collections import defaultdict
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Literal

from cognite.client import CogniteClient
from cognite.client import data_modeling as dm
from cognite.client.data_classes import ContextualizationJob, ExtractionPipelineRun, Row
from cognite.client.data_classes.data_modeling import (
    DirectRelationReference,
    Node,
    NodeApply,
    NodeOrEdgeData,
)
from cognite.client.data_classes.data_modeling.query import NodeResultSetExpression, Query, Select, SourceSelector
from cognite.client.exceptions import CogniteAPIError
from cognite.client.utils._text import shorten

# isort: split

from em_config import Config, ViewPropertyConfig
from em_constants import (
    BATCH_SIZE_API_SUBMIT,
    BATCH_SIZE_ENTITIES,
    COL_KEY_MAN_CONTEXTUALIZED,
    COL_KEY_MAN_MAPPING_ENTITY,
    COL_KEY_MAN_MAPPING_TARGET,
    COL_KEY_RULE_REGEXP_ENTITY,
    COL_KEY_RULE_REGEXP_TARGET,
    COL_MATCH_KEY,
    ENTITY_PAGE_SIZE,
    ENTITY_QUERY_NAME,
    FILTER_PATH_NODE_EXTERNAL_ID,
    FILTER_PATH_NODE_SPACE,
    HTTP_STATUS_BAD_REQUEST,
    KEY_ENTITY_EXISTING_TARGETS,
    KEY_ENTITY_EXT_ID,
    KEY_ENTITY_MATCH_VALUE,
    KEY_ENTITY_NAME,
    KEY_ENTITY_RULE_KEYS,
    KEY_ENTITY_SPACE,
    KEY_ENTITY_VIEW_ID,
    KEY_MATCH_TYPE,
    KEY_MATCHES,
    KEY_NAME,
    KEY_ORG_NAME,
    KEY_RULE,
    KEY_RULE_KEYS,
    KEY_SCOPE_PRIMARY,
    KEY_SCOPE_SECONDARY,
    KEY_SCORE,
    KEY_SOURCE,
    KEY_TARGET,
    KEY_TARGET_EXT_ID,
    KEY_TARGET_LINKS,
    KEY_TARGET_MATCH_VALUE,
    KEY_TARGET_NAME,
    KEY_TARGET_RULE_KEYS,
    KEY_TARGET_SPACE,
    KEY_TARGET_VIEW_ID,
    MATCH_TYPE_ENTITY,
    MATCH_TYPE_MANUAL,
    MATCH_TYPE_RULE,
    MATCHING_LIMIT_SOURCES_TARGETS,
    MAX_LINKS_PER_ENTITY,
    ML_MODEL_FEATURE_TYPE,
    PLACEHOLDER_NO_MATCH,
    PLACEHOLDER_NO_MATCH_TARGET,
    PROP_COL_EXTERNAL_ID,
    PROP_COL_LINK_NAME,
    PROP_COL_NAME,
    PROP_COL_SPACE,
    QUERY_FILTER_TYPE_ENTITIES,
    QUERY_FILTER_TYPE_TARGETS,
    SCORE_MANUAL_RULE_MATCH,
    STAT_STORE_MATCH_MODEL_ID,
    STAT_STORE_VALUE,
    STATUS_SUCCESS,
)
from em_logger import CogniteFunctionLogger
from em_pipeline_optimizations import RobustAPIClient
from em_pipeline_types import (
    EntityMatchingApiMatch,
    EntityMatchSource,
    ManualMappingDefinition,
    RawRowColumns,
    RuleMappingDefinition,
    StoredMatch,
    TargetMatchRecord,
)
from em_scope import scope_of, scope_properties

if TYPE_CHECKING:
    from cognite.extractorutils.uploader import RawUploadQueue


def _retry_apply(
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    items: list[NodeApply],
) -> None:
    """Apply DM instance updates with bounded exponential-backoff retry.

    Wraps `client.data_modeling.instances.apply` via RobustAPIClient so transient
    failures (rate-limiting, brief network blips, etc.) don't sink an entire
    matching run. No-op on empty input.
    """
    if not items:
        return
    RobustAPIClient(logger).robust_api_call(client.data_modeling.instances.apply, items)


def _flush_when_full(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    item_update: list[NodeApply],
    label: str,
    progress: str,
) -> list[NodeApply]:
    """Write the pending updates once a batch is full, so a long run writes as it goes.

    Returns:
        The updates still pending: none after a write, the same list otherwise.
    """
    if not config.parameters.dm_update or len(item_update) < BATCH_SIZE_API_SUBMIT:
        return item_update
    logger.info(
        f"==> {label} - Adding batch of {len(item_update)} items to data model, total count/matches: {progress}"
    )
    _retry_apply(client, logger, item_update)
    return []


def rule_keys(name: str, rule_mappings: list[RuleMappingDefinition] | None, pattern_key: str) -> list[str]:
    """Keys a name gets from the rules whose pattern matches it.

    Each key is the rule id and the captured groups concatenated. An operator's regex may
    make a group optional, and one that does not take part in the match captures None.

    Args:
        pattern_key: Which of the rule's patterns to apply, the entity or the target one.
    """
    keys: list[str] = []
    for rule in rule_mappings or ():
        if match := rule[pattern_key].search(name):  # type: ignore[literal-required]
            keys.append(rule[KEY_RULE] + "_" + "".join(group for group in match.groups() if group is not None))
    return keys


def file_data_set_id(client: CogniteClient, config: Config) -> int | None:
    """Internal id of the data set the function's CDF files go to, or None when none is configured.

    Raises:
        ValueError: The configured data set does not exist.
    """
    external_id = config.parameters.data_set_external_id
    if not external_id:
        return None
    data_set = client.data_sets.retrieve(external_id=external_id)
    if data_set is None:
        raise ValueError(f"Data set {external_id!r} in dataSetExternalId does not exist")
    return data_set.id


def instance_key(space: str | None, external_id: str) -> tuple[str, str]:
    """Identity of an instance for de-duplication and skip bookkeeping.

    An external ID is unique within a space, not across them, so the same one in two
    configured spaces is two distinct instances that each need matching and a write of
    their own. An unknown space keys as the empty string so such matches still
    de-duplicate against each other.
    """
    return (space or "", external_id)


def update_pipeline_run(
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    xid: str,
    status: str,
    match_count: int = 0,
    not_matches_count: int | None = None,
    input_msg: str | None = None,
    input_count: int | None = None,
) -> None:
    """Report a run on the extraction pipeline.

    Args:
        match_count: Entities that got at least one match.
        not_matches_count: Entities left unmatched because every candidate scored too low,
            or None when nothing has been scored yet. Submit only matches manual and rule
            mappings - the model scores in collect - so a score count there would read as
            a result the stage never produced.
        input_count: Entities considered. Submit knows this up front; callers that do not
            fall back to the matched plus unmatched total.
    """
    total_entities = input_count if input_count is not None else match_count + (not_matches_count or 0)
    if not_matches_count is None:
        counts = f"Entity matching of: {total_entities} input entities, {match_count} matched by manual or rule mapping"
    else:
        counts = (
            f"Entity matching of: {total_entities} input entities, Matched: {match_count} "
            f" - NOT matched due to low score: {not_matches_count}"
        )

    if status == STATUS_SUCCESS:
        msg = counts
        logger.info(msg)
        if input_msg:
            logger.info(input_msg)
    else:
        tb = f", traceback:\n{traceback.format_exc()}" if sys.exception() is not None else ""
        msg = f"{counts}, {input_msg or 'Unknown error'}{tb}"
        logger.error(msg)

    client.extraction_pipelines.runs.create(
        ExtractionPipelineRun(extpipe_external_id=xid, status=status, message=shorten(msg, 1000))
    )


def read_state_store(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    key: str,
) -> str:
    db = config.parameters.raw_db
    table = config.parameters.raw_table_state

    logger.info(f"Read state from DB: {db} Table: {table} Key: {key}")

    logger.debug("Create DB / Table for state if it does not exist")
    create_table(client, db, table)

    row = client.raw.rows.retrieve(db_name=db, table_name=table, key=key)
    if row and row.columns:
        return str(row.columns.get(STAT_STORE_VALUE, ""))
    return ""


def update_state_store(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    value: str,
    state_key: str,
) -> None:

    # Create DB / Table for state if it does not exist
    create_table(client, config.parameters.raw_db, config.parameters.raw_table_state)

    state_row = Row(state_key, {STAT_STORE_VALUE: value})
    client.raw.rows.insert(config.parameters.raw_db, config.parameters.raw_table_state, state_row)

    logger.debug(
        f"Update state store DB: {config.parameters.raw_db} "
        f"Table: {config.parameters.raw_table_state} Key: {state_key} Value: {value}"
    )


def manual_table_exists(client: CogniteClient, config: Config) -> bool:
    tables = client.raw.tables.list(config.parameters.raw_db, limit=None)
    return any(tbl.name == config.parameters.raw_table_ctx_manual for tbl in tables)


def rule_table_exists(client: CogniteClient, config: Config) -> bool:
    tables = client.raw.tables.list(config.parameters.raw_db, limit=None)
    return any(tbl.name == config.parameters.raw_table_ctx_rule for tbl in tables)


def read_manual_mappings(
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    config: Config,
) -> tuple[list[ManualMappingDefinition], dict[str, RawRowColumns]]:
    """Read manual mapping rows from RAW.

    Returns a `(mappings, mappings_input)` pair so the caller can do
    `manual_mappings, manual_mappings_input = read_manual_mappings(...)`.
    Both elements are empty when the manual mapping table doesn't exist. A failed
    read raises: carrying on without the mappings would silently leave the matching
    to the model.
    """
    manual_mappings: list[ManualMappingDefinition] = []
    manual_mappings_input: dict[str, RawRowColumns] = {}
    seen_mappings: set[str] = set()
    try:
        if not manual_table_exists(client, config):
            return manual_mappings, manual_mappings_input

        row_list = client.raw.rows.list(config.parameters.raw_db, config.parameters.raw_table_ctx_manual, limit=-1)
        for row in row_list:
            if not (
                config.parameters.run_all
                or not row.columns
                or COL_KEY_MAN_CONTEXTUALIZED not in row.columns
                or row.columns[COL_KEY_MAN_CONTEXTUALIZED] is not True
            ):
                continue

            # Make sure we don't add duplicate TS external IDs
            if not row.columns:
                continue
            entity_val = row.columns.get(COL_KEY_MAN_MAPPING_ENTITY)
            target_val = row.columns.get(COL_KEY_MAN_MAPPING_TARGET)
            if not entity_val or not target_val:
                logger.warning(f"Skipping malformed manual mapping row {row.key}: missing entity or target")
                continue
            entity = str(entity_val).strip()
            if entity not in seen_mappings:
                seen_mappings.add(entity)
                manual_mappings.append(
                    {
                        KEY_RULE: row.key,
                        COL_KEY_MAN_MAPPING_ENTITY: entity,
                        COL_KEY_MAN_MAPPING_TARGET: str(target_val).strip(),
                    }
                )
                manual_mappings_input[row.key] = row.columns  # type: ignore[assignment]

        logger.info(
            f"Number of manual mappings in table: {config.parameters.raw_db}/"
            f"{config.parameters.raw_table_ctx_manual}: {len(manual_mappings)}"
        )

    except CogniteAPIError as e:
        logger.error(f"Read manual mappings failed. Error: {e}")
        raise

    return manual_mappings, manual_mappings_input


def apply_manual_mappings(
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    config: Config,
    raw_uploader: "RawUploadQueue",
    manual_mappings: list[ManualMappingDefinition],
    manual_mappings_input: dict[str, RawRowColumns],
    good_matches: list[StoredMatch] | None = None,
    targets: list[TargetMatchRecord] | None = None,
) -> tuple[list[StoredMatch], int]:
    good_matches = [] if good_matches is None else list(good_matches)
    targets = [] if targets is None else list(targets)

    entity_view_id = config.data.entity_view.as_view_id()
    item_update = []
    clean_target_list = []
    cnt = 0

    try:
        targets_lookup = {target[KEY_TARGET_EXT_ID]: target for target in targets}
        target_spaces = {target[KEY_TARGET_EXT_ID]: target[KEY_TARGET_SPACE] for target in targets}
        entity_list = [mapping[COL_KEY_MAN_MAPPING_ENTITY] for mapping in manual_mappings]
        lookup_mapping = {
            mapping[COL_KEY_MAN_MAPPING_ENTITY]: mapping[COL_KEY_MAN_MAPPING_TARGET] for mapping in manual_mappings
        }
        key_lookup = {mapping[COL_KEY_MAN_MAPPING_ENTITY]: mapping[KEY_RULE] for mapping in manual_mappings}

        # Split entity_list into batches
        num_batches = (len(entity_list) - 1) // BATCH_SIZE_ENTITIES + 1 if entity_list else 0

        if num_batches > 1:
            logger.info(
                f"Entity list has {len(entity_list)} items, "
                f"splitting into {num_batches} batches of up to {BATCH_SIZE_ENTITIES}"
            )

        # Process in batches
        for batch_idx in range(0, len(entity_list), BATCH_SIZE_ENTITIES):
            batch_entity_list = entity_list[batch_idx : batch_idx + BATCH_SIZE_ENTITIES]
            batch_num = batch_idx // BATCH_SIZE_ENTITIES + 1

            if num_batches > 1:
                logger.info(f"Processing batch {batch_num}/{num_batches} with {len(batch_entity_list)} entities")

            # Get instances for current batch
            instances = list_instances_by_external_id_direct(
                client=client, config=config, external_id=batch_entity_list, logger=logger
            )

            # Process entities in current batch

            for entity in instances:
                cnt += 1
                if entity.external_id not in lookup_mapping:
                    continue

                target_ext_id = lookup_mapping[entity.external_id]
                if not target_ext_id:
                    logger.warning(f"Manual mapping target ref is empty for entity: {entity.external_id}, skipping")
                    continue

                properties = entity.properties.get(entity_view_id) if entity.properties else None
                if not properties or PROP_COL_NAME not in properties:
                    logger.warning(f"Entity: {entity.external_id} is missing properties or name, skipping")
                    continue

                # An entity that has never been linked - the normal state of one mapped by
                # hand - leaves the property out of the response altogether.
                links_property = properties.get(PROP_COL_LINK_NAME)

                entity_targets: list[str] = []
                if not config.parameters.remove_old_links:
                    # keep old target links
                    if links_property:
                        entity_targets = get_links_from_entity(links_property)
                        remember_link_spaces(target_spaces, links_property)
                else:
                    clean_target_list = clean_links(config, entity.space, entity.external_id, clean_target_list)

                entity_targets = [*entity_targets, target_ext_id]

                item_update = add_to_items(
                    config,
                    logger,
                    item_update,
                    entity_targets,
                    entity.external_id,
                    entity_view_id,
                    entity_space=entity.space,
                    target_spaces=target_spaces,
                )

                if target_ext_id in targets_lookup:
                    target = targets_lookup[target_ext_id]
                    target_name = target[KEY_ORG_NAME]
                    target_view_id = str(config.data.target_view.as_view_id())
                else:
                    target_name = PLACEHOLDER_NO_MATCH_TARGET
                    target_view_id = PLACEHOLDER_NO_MATCH_TARGET

                stored: StoredMatch = {
                    KEY_MATCH_TYPE: MATCH_TYPE_MANUAL,
                    KEY_ENTITY_EXT_ID: entity.external_id,
                    KEY_ENTITY_SPACE: entity.space,
                    KEY_ENTITY_NAME: properties[PROP_COL_NAME],
                    KEY_ENTITY_MATCH_VALUE: entity.external_id,
                    KEY_ENTITY_VIEW_ID: str(config.data.entity_view.as_view_id()),
                    KEY_ENTITY_EXISTING_TARGETS: _links_as_json(links_property or []),
                    KEY_SCORE: SCORE_MANUAL_RULE_MATCH,
                    KEY_TARGET_NAME: target_name,
                    KEY_TARGET_MATCH_VALUE: target_ext_id,
                    KEY_TARGET_EXT_ID: target_ext_id,
                    KEY_TARGET_SPACE: target_spaces.get(target_ext_id),
                    KEY_TARGET_VIEW_ID: target_view_id,
                }
                if scope_properties(config.parameters):
                    stored[KEY_SCOPE_PRIMARY], stored[KEY_SCOPE_SECONDARY] = scope_of(properties, config.parameters)
                good_matches.append(stored)

                row_key = key_lookup[entity.external_id]
                mapping = manual_mappings_input[row_key].copy()
                mapping[COL_KEY_MAN_CONTEXTUALIZED] = True
                raw_uploader.add_to_upload_queue(
                    config.parameters.raw_db,
                    config.parameters.raw_table_ctx_manual,
                    Row(row_key, mapping),
                )

                # Flush the queue once it is full. `cnt` counts every instance read,
                # including the ones skipped above, so it cannot stand in for the queue
                # length: the batch would overshoot the cap and a skip landing on a
                # multiple of it would miss the flush entirely.
                if config.parameters.dm_update and len(item_update) >= BATCH_SIZE_API_SUBMIT:
                    _retry_apply(client, logger, clean_target_list)
                    clean_target_list = []
                item_update = _flush_when_full(
                    client,
                    config,
                    logger,
                    item_update,
                    "Mapping table based matching",
                    f"{cnt} / {len(manual_mappings)}",
                )

            if num_batches > 1:
                logger.info(f"Completed batch {batch_num}/{num_batches}")

        if config.parameters.dm_update:
            _retry_apply(client, logger, clean_target_list)

            # Apply the updates to the data model
            _retry_apply(client, logger, item_update)
            if len(item_update) > 0:
                if cnt == 0:
                    logger.info(
                        "==> Mapping table based matching - "
                        "No items added to data model based on new items found and manual mappings"
                    )
                else:
                    logger.info(
                        f"==> Mapping table based matching - Adding batch of {len(item_update)} items "
                        f"to data model, total count/matches: {cnt} / {len(manual_mappings)}"
                    )

        raw_uploader.upload()

        return good_matches, cnt

    except CogniteAPIError as e:
        logger.error(f"Cognite API error while applying manual mappings: {e}")
        raise


def _link_identity(link: object) -> tuple[str, str] | None:
    """(external_id, space) of a direct relation, or None if the value is not a link.

    The SDK returns `DirectRelationReference` objects. JSON round-trips through RAW as
    dictionaries. Both have to be accepted, or existing links are dropped or crash the run.
    """
    if isinstance(link, DirectRelationReference):
        if link.external_id and link.space:
            return link.external_id, link.space
        return None
    if isinstance(link, dict):
        ext_id = link.get(PROP_COL_EXTERNAL_ID)
        space = link.get(PROP_COL_SPACE)
        if ext_id and space:
            return str(ext_id), str(space)
    return None


def _links_as_json(links: list[object]) -> str:
    """JSON for existing links, so they survive the matching API round-trip."""
    serialized = []
    for link in links:
        identity = _link_identity(link)
        if identity is None:
            continue
        ext_id, space = identity
        serialized.append({PROP_COL_SPACE: space, PROP_COL_EXTERNAL_ID: ext_id})
    return json.dumps(serialized)


def get_links_from_entity(links_property: list[object] | None) -> list[str]:
    links: list[str] = []
    for link in links_property or []:
        identity = _link_identity(link)
        if identity:
            links.append(identity[0])
    return links


def read_entities(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    is_selected: dm.filters.Filter | None,
) -> list[Node]:
    """Entities in the configured spaces that match the filter, read a page at a time.

    Only the properties matching uses are read, and each page is retried on transient errors.
    """
    view_config = config.data.entity_view
    view_id = view_config.as_view_id()
    parameters = config.parameters
    properties = [PROP_COL_NAME, view_config.search_property, PROP_COL_LINK_NAME]
    properties += [name for name in (parameters.primary_scope_property, parameters.secondary_scope_property) if name]
    in_spaces = dm.filters.In(FILTER_PATH_NODE_SPACE, view_config.instance_spaces)
    query = Query(
        with_={
            ENTITY_QUERY_NAME: NodeResultSetExpression(
                filter=dm.filters.And(in_spaces, is_selected) if is_selected is not None else in_spaces,
                limit=ENTITY_PAGE_SIZE,
            )
        },
        select={ENTITY_QUERY_NAME: Select([SourceSelector(view_id, list(dict.fromkeys(properties)))])},
    )
    api = RobustAPIClient(logger)
    entities: list[Node] = []
    while True:
        result = api.robust_api_call(client.data_modeling.instances.query, query)
        page = list(result[ENTITY_QUERY_NAME])
        entities.extend(page)
        cursor = result.cursors.get(ENTITY_QUERY_NAME)
        if not cursor or len(page) < ENTITY_PAGE_SIZE:
            return entities
        query.cursors = {ENTITY_QUERY_NAME: cursor}


def list_instances_by_external_id_direct(
    client: CogniteClient,
    config: Config,
    external_id: list[str],
    logger: CogniteFunctionLogger,
) -> Sequence[Node]:
    """Entities with one of the given external IDs, for applying manual mappings."""
    entity_view_id = config.data.entity_view.as_view_id()
    is_selected = dm.filters.And(
        dm.filters.HasData(views=[entity_view_id]), dm.filters.In(FILTER_PATH_NODE_EXTERNAL_ID, external_id)
    )
    matching_instances = read_entities(client, config, logger, is_selected)
    logger.info(f"Found {len(matching_instances)} instances for manual mappings")
    return matching_instances


def read_rule_mappings(
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    config: Config,
) -> list[RuleMappingDefinition]:
    """Read rule-based mapping definitions from RAW.

    Each rule's entity/target regex is compiled once here and stored as a
    `re.Pattern` in the resulting dict, so the per-target / per-entity inner
    loops can call `pattern.search(name)` directly instead of re-compiling
    (or relying on `re`'s LRU cache) on every name. For pipelines with
    thousands of entities and a handful of rules this is a measurable hot
    path.
    """
    rule_mappings: list[RuleMappingDefinition] = []

    try:
        if not rule_table_exists(client, config):
            return rule_mappings

        row_list = client.raw.rows.list(config.parameters.raw_db, config.parameters.raw_table_ctx_rule, limit=-1)
        idx = 1
        for row in row_list:
            if not row.columns:
                continue

            entity_pattern_val = row.columns.get(COL_KEY_RULE_REGEXP_ENTITY)
            target_pattern_val = row.columns.get(COL_KEY_RULE_REGEXP_TARGET)
            if not entity_pattern_val or not target_pattern_val:
                logger.warning(f"Skipping malformed rule mapping row {row.key}: missing entity or target regex")
                idx += 1
                continue

            entity_pattern_str = str(entity_pattern_val).strip()
            target_pattern_str = str(target_pattern_val).strip()
            try:
                entity_pattern = re.compile(entity_pattern_str)
                target_pattern = re.compile(target_pattern_str)
            except re.error as exc:
                logger.warning(
                    f"Skipping rule {idx} due to invalid regex "
                    f"(entity={entity_pattern_str!r}, target={target_pattern_str!r}): {exc}"
                )
                idx += 1
                continue

            rule_mappings.append(
                {
                    KEY_RULE: f"{idx}",
                    COL_KEY_RULE_REGEXP_ENTITY: entity_pattern,  # type: ignore[misc]
                    COL_KEY_RULE_REGEXP_TARGET: target_pattern,  # type: ignore[misc]
                }
            )
            idx += 1
        logger.info(f"Number of mapping rules : {len(rule_mappings)}")
    except CogniteAPIError as e:
        logger.error(f"Read rule based mappings failed. Error: {e}")
        raise

    return rule_mappings


def warn_on_cross_space_duplicates(
    instances: Sequence[Node],
    instance_type: str,
    view_config: ViewPropertyConfig,
    logger: CogniteFunctionLogger,
) -> None:
    """Warn when one external ID exists in several of the configured instance spaces.

    Each instance is matched and updated in the space it was read from, so duplicates are
    handled independently. What remains keyed on external ID alone is the manual mapping
    table in RAW, which has no space column, and the space a target link resolves to.
    Skipped unless several spaces are configured, where the situation cannot arise.

    Args:
        instance_type: What to call these instances in the warning, e.g. "assets".
    """
    if len(view_config.instance_spaces) < 2:
        return

    space_by_external_id: dict[str, str] = {}
    duplicates: dict[str, tuple[str, str]] = {}
    for instance in instances:
        first_space = space_by_external_id.setdefault(instance.external_id, instance.space)
        if first_space != instance.space and instance.external_id not in duplicates:
            duplicates[instance.external_id] = (first_space, instance.space)

    if not duplicates:
        return

    examples = ", ".join(f"{ext_id} in {spaces[0]} and {spaces[1]}" for ext_id, spaces in list(duplicates.items())[:5])
    logger.warning(
        f"{len(duplicates)} {instance_type} external IDs exist in more than one configured instance space. "
        f"Each instance is matched and updated in its own space, but manual mappings and target links are "
        f"resolved by external ID alone and so apply to every copy - give each space unique external IDs "
        f"or configure a single space. Examples: {examples}"
    )


def match_values(
    properties: Mapping[str, object],
    search_property: str,
    org_name: str,
    *,
    list_selection: Literal["all", "longest"] = "longest",
) -> list[str]:
    """Values to match an instance on, falling back to its name.

    An unset property is left out of the response entirely, but one set to `[]` or to a
    blank string is not, and neither carries anything to match on. All three mean the
    same thing here, so all three fall back to the name - otherwise an empty list leaves
    the instance out of the match set altogether and a blank string matches it on nothing.

    For list-valued search properties (typically aliases):
    - ``list_selection="longest"`` (input entities, default): keep only the longest usable
      entry so one source instance is not duplicated into several match candidates.
    - ``list_selection="all"`` (targets): keep every usable entry so alternate spellings
      remain matchable.

    Args:
        properties: The instance's properties for the view being read.
        search_property: Property whose value is handed to the matching model.
        org_name: The instance's name, used when the search property has nothing usable.
        list_selection: How to reduce a list-valued search property.
    """
    value = properties.get(search_property)
    candidates = value if isinstance(value, list) else [value]
    usable = [str(item) for item in candidates if item is not None and str(item).strip()]
    if not usable:
        return [org_name]
    if list_selection == "longest":
        return [max(usable, key=len)]
    return usable


def get_new_entities(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    list_good_entities: list[tuple[str, str]] | None = None,
    rule_mappings: list[RuleMappingDefinition] | None = None,
) -> list[EntityMatchSource]:

    entities_source: list[EntityMatchSource] = []

    entity_view_config = config.data.entity_view
    entity_view_id = entity_view_config.as_view_id()

    logger.debug(f"Get new entities from view: {entity_view_id}, based on config: {entity_view_config}")
    is_selected = get_query_filter(entity_view_config, logger)

    listed_entities = read_entities(client, config, logger, is_selected)

    # Drop already-linked entities before the duplicate warning and the count log.
    # A link list of None or `[]` still counts as unmatched; `runAll` keeps every entity.
    already_linked = 0
    new_entities: Sequence[Node] = listed_entities
    if not config.parameters.run_all:
        unmatched: list[Node] = []
        for entity in listed_entities:
            properties = entity.properties.get(entity_view_id) if entity.properties else None
            if properties and properties.get(PROP_COL_LINK_NAME):
                already_linked += 1
                continue
            unmatched.append(entity)
        new_entities = unmatched

    warn_on_cross_space_duplicates(new_entities, QUERY_FILTER_TYPE_ENTITIES, entity_view_config, logger)

    item_update = []

    skipped = f" (skipped {already_linked} already linked)" if already_linked else ""
    logger.info(
        f"Number of entities to process: {len(new_entities)}{skipped} "
        f"NOTE: Rule based regular expressions are applied to the '{PROP_COL_NAME}' property"
    )
    matched_entities = set(list_good_entities or ())
    scoped = bool(scope_properties(config.parameters))
    skipped_missing = 0

    for entity in new_entities:
        # test if just matched and skip if so - keyed on space as well, so an entity
        # sharing an external ID with an already matched one elsewhere is still processed
        if instance_key(entity.space, entity.external_id) in matched_entities:
            logger.debug(f"Entity: {entity.external_id} in {entity.space} just matched, skipping")
            continue
        properties = entity.properties.get(entity_view_id) if entity.properties else None
        if not properties or PROP_COL_NAME not in properties:
            skipped_missing += 1
            logger.missing_property_skip("Entity", entity.external_id, skipped_missing)
            continue

        # Rule based matching uses the name property to match entities to targets
        org_name = str(properties[PROP_COL_NAME])
        entity_rule_keys = rule_keys(org_name, rule_mappings, COL_KEY_RULE_REGEXP_ENTITY)

        targets = []
        if (
            not config.parameters.remove_old_links or not config.parameters.dm_update
        ):  # if dmUpdate is False, keep old target links
            # Keep old target links. An entity that has never been linked either omits the
            # property or reads back as None; both would serialise to JSON null and break
            # len() in the consumers.
            targets = properties.get(PROP_COL_LINK_NAME) or []
        else:
            item_update = clean_links(config, entity.space, entity.external_id, item_update)

        # add entities for files used to match between file references in P&ID to other files
        search_prop = entity_view_config.search_property
        entity_names = match_values(properties, search_prop, org_name, list_selection="longest")
        targets_json = _links_as_json(targets)
        for entity_name in entity_names:
            record: EntityMatchSource = {
                KEY_ENTITY_EXT_ID: entity.external_id,
                KEY_ENTITY_SPACE: entity.space,
                KEY_NAME: entity_name,
                KEY_ORG_NAME: org_name,
                KEY_TARGET_LINKS: targets_json,
                KEY_RULE_KEYS: entity_rule_keys or None,
            }
            if scoped:
                record[KEY_SCOPE_PRIMARY], record[KEY_SCOPE_SECONDARY] = scope_of(properties, config.parameters)
            entities_source.append(record)
            logger.debug(f"Entity: {entity.external_id} - {entity_name} ({org_name})")

    logger.missing_property_skip_summary(QUERY_FILTER_TYPE_ENTITIES, skipped_missing)
    logger.info(f"Num new entities: {len(entities_source)} from view: {entity_view_id}")

    if config.parameters.remove_old_links and len(item_update) > 0:
        _retry_apply(client, logger, item_update)
        logger.info(f"Cleaned up {QUERY_FILTER_TYPE_TARGETS} links for {len(item_update)} entities")

    return entities_source


def clean_links(config: Config, entity_space: str, entity_ext_id: str, item_update: list[NodeApply]) -> list[NodeApply]:

    entity_view_id = config.data.entity_view.as_view_id()

    item_update.append(
        NodeApply(
            space=entity_space,
            external_id=entity_ext_id,
            sources=[
                NodeOrEdgeData(
                    source=entity_view_id,
                    properties={PROP_COL_LINK_NAME: None},
                )
            ],
        )
    )

    return item_update


def get_query_filter(
    view_config: ViewPropertyConfig,
    logger: CogniteFunctionLogger,
    include_has_data: bool = True,
) -> dm.filters.Filter | None:
    """Build the DMS filter that scopes a read to the configured view.

    Whether an entity is already matched is decided in `get_new_entities` rather than
    here: `exists` counts an empty array as a value on the query endpoint, so
    `NOT exists(links)` would drop every entity whose link list was written as `[]`.
    """
    filters: list[dm.filters.Filter] = []
    dbg_msg = f"For view: {view_config.as_view_id()}, instance spaces: {view_config.instance_spaces}"

    if include_has_data:
        filters.append(dm.filters.HasData(views=[view_config.as_view_id()]))
        dbg_msg = f"{dbg_msg} - Entity filter: HasData = True"
    else:
        dbg_msg = f"{dbg_msg} - Entity filter: HasData skipped (sources already scope instances)"

    if view_config.filter_property and view_config.filter_values:
        is_filter_param = dm.filters.In(
            view_config.as_property_ref(view_config.filter_property), view_config.filter_values
        )
        filters.append(is_filter_param)
        dbg_msg = f"{dbg_msg} Entity filtering on: '{view_config.filter_values}' IN: '{view_config.filter_property}'"

    logger.info(dbg_msg)

    if not filters:
        return None
    if len(filters) == 1:
        return filters[0]
    return dm.filters.And(*filters)


def submit_predict_job(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    matching_model_id: str,
    match_to: list[TargetMatchRecord],
    match_from: list[EntityMatchSource],
) -> ContextualizationJob:
    """Create or reuse the matching model and start a predict job for the entities.

    The job is returned without reading `job.result`, which is what would block until
    the matching finishes in CDF. Collect polls it instead.

    Args:
        matching_model_id: Model to reuse, or an empty string to fit a new one.
        match_to: Targets to match against.
        match_from: Entities to match.

    Returns:
        The started predict job, carrying the job id and token collect needs.
    """
    try:
        if matching_model_id:
            logger.debug(f"Get existing matching model: {matching_model_id}")
            model = client.entity_matching.retrieve(id=int(matching_model_id))
        else:
            model = client.entity_matching.fit(
                sources=match_from[:MATCHING_LIMIT_SOURCES_TARGETS],
                targets=match_to[:MATCHING_LIMIT_SOURCES_TARGETS],
                match_fields=[(COL_MATCH_KEY, COL_MATCH_KEY)],
                feature_type=ML_MODEL_FEATURE_TYPE,
            )
            logger.info(f"Created new matching model: {model.id}")
            update_state_store(client, config, logger, str(model.id), STAT_STORE_MATCH_MODEL_ID)

        if not model:
            raise RuntimeError("Failed to create or retrieve matching model")

        return model.predict(sources=match_from, targets=match_to, num_matches=1)

    except (CogniteAPIError, ValueError) as e:
        logger.error(f"ERROR: Failed to get matching model and start prediction. Error: {type(e)}({e})")
        raise


def apply_rule_mappings(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    good_matches: list[StoredMatch],
    target_dest: list[TargetMatchRecord],
    new_entities: list[EntityMatchSource],
) -> tuple[list[StoredMatch], int]:

    # Use set instead of list for O(1) lookups. Both sides are keyed on space and external
    # ID, so a pair is only a duplicate when it is the same pair of instances.
    good_matches_set = {
        (
            instance_key(match.get(KEY_ENTITY_SPACE), match[KEY_ENTITY_EXT_ID]),
            instance_key(match.get(KEY_TARGET_SPACE), match[KEY_TARGET_EXT_ID]),
        )
        for match in good_matches
    }
    matched_entities = {instance_key(match.get(KEY_ENTITY_SPACE), match[KEY_ENTITY_EXT_ID]) for match in good_matches}

    key_field = KEY_RULE_KEYS  # The field in the dictionaries that contains the rule keys
    cnt = 0

    try:
        # Build an inverted index for target_dest
        # Format: { 'rule_key_value': [dict_from_target_dest_1, dict_from_target_dest_2, ...] }
        index1 = defaultdict(list)
        # Keyed on (space, external ID) so two entities sharing an external ID keep their
        # own link lists and are each written to the space they came from.
        matches: dict[tuple[str, str], list[str]] = defaultdict(list)
        target_spaces = {target[KEY_TARGET_EXT_ID]: target[KEY_TARGET_SPACE] for target in target_dest}

        for d1 in target_dest:
            r_keys = d1.get(key_field)
            if not r_keys:  # Ensure the key_field exists
                continue  # Skip if no rule keys are present
            for r_key in r_keys:
                index1[r_key].append(d1)

        # To avoid duplicate matches (e.g., if A1 matches B1, we don't want B1 matching A1 back)
        # or to handle cases where multiple rule_keys cause the same pair to match,
        # we use a set of unique pairs.
        unique_matches_tracker = set()

        cnt = len(new_entities)

        for d2 in new_entities:
            r_keys = d2.get(key_field)
            if not r_keys:  # Ensure the key_field exists
                continue  # Skip if no rule keys are present
            set2 = set(r_keys)  # Convert to set once

            # Skip if entity already has been matched
            entity = instance_key(d2[KEY_ENTITY_SPACE], d2[KEY_ENTITY_EXT_ID])
            if entity in matched_entities:
                logger.debug(
                    f"Entity: {d2[KEY_ENTITY_EXT_ID]} in {d2[KEY_ENTITY_SPACE]} "
                    "already has been matched manually, skipping"
                )
                continue

            for r_key_from_d2 in set2:
                if r_key_from_d2 in index1:
                    for d1_match in index1[r_key_from_d2]:
                        # Both instances are identified by space and external ID, so the
                        # same external ID in another space is a separate pair
                        pair = (entity, instance_key(d1_match[KEY_TARGET_SPACE], d1_match[KEY_TARGET_EXT_ID]))

                        if pair not in unique_matches_tracker:
                            if pair in good_matches_set:
                                logger.debug(
                                    f"Match already exists in good matches: "
                                    f"{d1_match[KEY_TARGET_EXT_ID]} - {d2[KEY_ENTITY_EXT_ID]}"
                                )
                                continue
                            good_matches_set.add(pair)

                            unique_target_list = list(set(matches.get(entity, ())))
                            target_id = d1_match[KEY_TARGET_EXT_ID]
                            if target_id and target_id not in unique_target_list:
                                unique_target_list = [*unique_target_list, target_id]
                                stored: StoredMatch = {
                                    KEY_MATCH_TYPE: MATCH_TYPE_RULE,
                                    KEY_ENTITY_EXT_ID: d2[KEY_ENTITY_EXT_ID],
                                    KEY_ENTITY_SPACE: d2[KEY_ENTITY_SPACE],
                                    KEY_ENTITY_NAME: d2[KEY_ORG_NAME],
                                    KEY_ENTITY_MATCH_VALUE: d2[KEY_NAME],
                                    KEY_ENTITY_VIEW_ID: str(config.data.entity_view.as_view_id()),
                                    KEY_ENTITY_EXISTING_TARGETS: d2[KEY_TARGET_LINKS],
                                    KEY_ENTITY_RULE_KEYS: json.dumps(d2[KEY_RULE_KEYS]),
                                    KEY_SCORE: SCORE_MANUAL_RULE_MATCH,
                                    KEY_TARGET_NAME: d1_match[KEY_ORG_NAME],
                                    KEY_TARGET_MATCH_VALUE: d1_match[KEY_NAME],
                                    KEY_TARGET_EXT_ID: d1_match[KEY_TARGET_EXT_ID],
                                    KEY_TARGET_SPACE: d1_match[KEY_TARGET_SPACE],
                                    KEY_TARGET_VIEW_ID: str(config.data.target_view.as_view_id()),
                                    KEY_TARGET_RULE_KEYS: json.dumps(d1_match[KEY_RULE_KEYS]),
                                }
                                _copy_scope(d2, stored)
                                good_matches.append(stored)

                            existing_target_list = json.loads(d2[KEY_TARGET_LINKS])
                            if len(existing_target_list) > 0:
                                remember_link_spaces(target_spaces, existing_target_list)
                                for target in existing_target_list:
                                    identity = _link_identity(target)
                                    if identity and identity[0] not in unique_target_list:
                                        unique_target_list = [*unique_target_list, identity[0]]

                            matches[entity] = unique_target_list
                            unique_matches_tracker.add(pair)

        item_update = []

        # Iterate through the matches and prepare the item updates

        for (entity_space, entity_ext_id), target_ext_ids in matches.items():
            item_update = add_to_items(
                config,
                logger,
                item_update,
                target_ext_ids,
                entity_ext_id,
                config.data.entity_view.as_view_id(),
                entity_space=entity_space or None,
                target_spaces=target_spaces,
            )

            item_update = _flush_when_full(
                client, config, logger, item_update, "Rule based matching", f"{cnt} / {len(matches)}"
            )

        if config.parameters.dm_update:
            # Apply the updates to the data model
            _retry_apply(client, logger, item_update)

            if cnt == 0:
                logger.info(
                    "==> Rule based matching - "
                    "No items added to data model based on new items found and rule based mappings"
                )
            else:
                logger.info(
                    f"==> Rule based matching - Adding batch of {len(item_update)} items to data model, "
                    f"total count/matches: {cnt} / {len(matches)}"
                )

        return good_matches, len(matches)

    except CogniteAPIError as e:
        logger.error(f"Cognite API error while applying rule-based mappings: {e}")
        raise


def select_and_apply_matches(
    client: CogniteClient,
    config: Config,
    logger: CogniteFunctionLogger,
    good_matches: list[StoredMatch],
    match_results: list[EntityMatchingApiMatch],
) -> tuple[list[StoredMatch], list[StoredMatch], int]:
    """
    Select and apply matches based on filtering threshold. Matches with score above threshold are updating time series
    with target ID When matches are updated, metadata property with information about the match is added to time series
    to indicate that it has been matched.

    Args:
        client: Instance of CogniteClient
        config: Instance of ContextConfig
        match_results: list of matches from entity matching
        entity_meta_dict: dictionary with time series id and metadata

    Returns:
        list of good matches
        list of bad matches
    """
    bad_matches = []
    item_update = []
    cnt = 0

    entity_view_id = config.data.entity_view.as_view_id()
    target_view_id = config.data.target_view.as_view_id()

    # Use set instead of list for O(1) lookups. Both sides are keyed on space and external
    # ID, so a pair is only a duplicate when it is the same pair of instances.
    good_matches_set = {
        (
            instance_key(match.get(KEY_ENTITY_SPACE), match[KEY_ENTITY_EXT_ID]),
            instance_key(match.get(KEY_TARGET_SPACE), match[KEY_TARGET_EXT_ID]),
        )
        for match in good_matches
    }
    matched_entities = {instance_key(match.get(KEY_ENTITY_SPACE), match[KEY_ENTITY_EXT_ID]) for match in good_matches}
    new_good_matches = []
    skipped_already_matched = 0
    try:
        for match in match_results:
            # Skip if entity already has been matched - an entity sharing an external ID
            # with an already matched one in another space is a different instance
            source = match[KEY_SOURCE]
            entity = instance_key(source.get(KEY_ENTITY_SPACE), source[KEY_ENTITY_EXT_ID])
            if entity in matched_entities:
                skipped_already_matched += 1
                continue

            if match[KEY_MATCHES]:
                if match[KEY_MATCHES][0][KEY_SCORE] >= config.parameters.auto_approval_threshold:
                    entity_ext_id = source[KEY_ENTITY_EXT_ID]
                    target = match[KEY_MATCHES][0][KEY_TARGET]
                    target_ext_id = target[KEY_TARGET_EXT_ID]

                    pair = (entity, instance_key(target.get(KEY_TARGET_SPACE), target_ext_id))
                    if pair in good_matches_set:
                        logger.debug(f"Match already exists in good matches: {target_ext_id} - {entity_ext_id}")
                        continue
                    else:
                        good_matches_set.add(pair)

                    new_good_matches.append(add_to_dict(match, str(entity_view_id), str(target_view_id)))
                else:
                    bad_matches.append(add_to_dict(match, str(entity_view_id), str(target_view_id)))
            else:
                bad_matches.append(add_to_dict(match, str(entity_view_id), str(target_view_id)))

        logger.info(
            f"Predict returned {len(match_results)} result(s); "
            f"skipped {skipped_already_matched} already matched by manual or rule mapping"
        )
        logger.info(f"Got {len(new_good_matches)} matches with score >= {config.parameters.auto_approval_threshold}")
        logger.info(f"Got {len(bad_matches)} matches with score < {config.parameters.auto_approval_threshold}")

        cnt = len(new_good_matches) + len(bad_matches)
        # Update time series with matches
        for match in new_good_matches:
            entity_ext_id = match[KEY_ENTITY_EXT_ID]
            target_ext_id = match[KEY_TARGET_EXT_ID]
            entity_targets = match[KEY_ENTITY_EXISTING_TARGETS]
            target_space = match[KEY_TARGET_SPACE]

            item_update = add_to_items(
                config,
                logger,
                item_update,
                [target_ext_id],
                entity_ext_id,
                entity_view_id,
                entity_targets,
                entity_space=match[KEY_ENTITY_SPACE],
                target_spaces={target_ext_id: target_space} if target_space else None,
            )

            item_update = _flush_when_full(
                client, config, logger, item_update, "Entity matching", f"{cnt} / {len(new_good_matches)}"
            )

        if config.parameters.dm_update:
            _retry_apply(client, logger, item_update)
            if cnt == 0:
                logger.info(
                    "==> Entity matching - No items added to data model based on new items found and entity matching"
                )
            else:
                logger.info(
                    f"==> Entity matching - Adding batch of {len(item_update)} items to data model, "
                    f"total count/matches: {cnt} / {len(new_good_matches)}"
                )

        return good_matches + new_good_matches, bad_matches, len(new_good_matches)

    except (KeyError, TypeError, ValueError) as e:
        # Reporting no matches here would be indistinguishable from a run that genuinely
        # found none, so let the caller mark the pipeline run failed.
        logger.error(f"Failed to parse results from entity matching - error: {type(e)}({e})")
        raise


def remember_link_spaces(target_spaces: dict[str, str], links: list[object] | None) -> None:
    """Record the space each existing target link points into.

    Links are re-applied by external ID only, so without this a link to a target outside
    the current target set would fall back to the first configured target space and be
    moved. Spaces read from the target view win, hence `setdefault` rather than assignment.
    """
    for link in links or []:
        identity = _link_identity(link)
        if identity:
            ext_id, space = identity
            target_spaces.setdefault(ext_id, space)


def add_to_items(
    config: Config,
    logger: CogniteFunctionLogger,
    item_update: list[NodeApply],
    target_ext_ids: list[str],
    entity_ext_id: str,
    entity_view_id: dm.ViewId,
    entity_targets: str | list[object] | None = None,
    entity_space: str | None = None,
    target_spaces: dict[str, str] | None = None,
) -> list[NodeApply]:
    """Queue a node update linking an entity to its targets.

    Each instance is written to the space it was read from. Where a space is unknown the
    first configured space is used and the fallback is logged, unless the view is
    configured with a single space, where the fallback is always correct.

    Args:
        item_update: Queue of pending node updates, appended to in place.
        entity_space: Space the entity lives in.
        target_spaces: Target external ID to the space it lives in.

    Returns:
        The same queue, with this entity's update appended.
    """
    target_spaces = target_spaces or {}
    default_target_space = config.data.target_view.default_instance_space
    # With one space per view the fallback is by definition the right space. With several,
    # it is a guess that can point the update at a space the instance does not live in.
    warn_on_entity_fallback = len(config.data.entity_view.instance_spaces) > 1
    warn_on_target_fallback = len(config.data.target_view.instance_spaces) > 1

    if entity_space is None:
        entity_space = config.data.entity_view.default_instance_space
        if warn_on_entity_fallback:
            logger.warning(
                f"Unknown instance space for entity: {entity_ext_id} - writing the update to "
                f"{entity_space}. A new node is created there if the entity lives in another space."
            )

    targets = []

    if entity_targets:
        # The string round-trips through the matching API, so a JSON null or an already
        # parsed list reaching this point cannot be ruled out.
        try:
            decoded = json.loads(entity_targets) if isinstance(entity_targets, str) else entity_targets
            targets_list = decoded if isinstance(decoded, list) else []
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"Failed to parse existing targets for entity: {entity_ext_id}")
            targets_list = []

        for target in targets_list or []:
            identity = _link_identity(target)
            if identity is None:
                # This list replaces the whole link property, so skipping drops the link
                # from the entity - never silently.
                logger.warning(
                    f"Existing link on entity: {entity_ext_id} is not a complete "
                    f"space/externalId object - dropping it: {target}"
                )
                continue
            ext_id, space = identity
            # The target view is authoritative; the link's own space is only a fallback
            # for targets outside the current target set.
            targets.append(
                DirectRelationReference(
                    space=target_spaces.get(ext_id, space),
                    external_id=ext_id,
                )
            )

    # Add new targets to the entity
    existing_target_ids = {target.external_id for target in targets}
    for target_ext_id in target_ext_ids:
        if not target_ext_id:
            logger.warning(f"Asset external ID is empty for entity: {entity_ext_id}, skipping")
            continue
        if target_ext_id in existing_target_ids:
            logger.debug(f"Asset: {target_ext_id} already exists in entity: {entity_ext_id}, skipping")
            continue
        logger.debug(f"Adding target: {target_ext_id} to entity: {entity_ext_id}")
        target_space = target_spaces.get(target_ext_id)
        if target_space is None:
            target_space = default_target_space
            if warn_on_target_fallback:
                logger.warning(
                    f"Unknown instance space for target: {target_ext_id} linked from entity: "
                    f"{entity_ext_id} - linking to {target_space}. The link dangles if the target "
                    f"lives in another space."
                )
        targets.append(DirectRelationReference(space=target_space, external_id=target_ext_id))
        existing_target_ids.add(target_ext_id)

    if len(targets) > MAX_LINKS_PER_ENTITY:
        logger.warning(
            f"Entity: {entity_ext_id} has more than {MAX_LINKS_PER_ENTITY} targets - "
            f"has {len(targets)} targets, will only add {MAX_LINKS_PER_ENTITY}. "
            "Please review your rule/matching model to prevent overly broad matching."
        )
        targets = targets[:MAX_LINKS_PER_ENTITY]

    item_update.append(
        NodeApply(
            space=entity_space,
            external_id=entity_ext_id,
            sources=[
                NodeOrEdgeData(
                    source=entity_view_id,
                    properties={PROP_COL_LINK_NAME: targets},
                )
            ],
        )
    )

    logger.debug(f"Added entity: {entity_ext_id} to targets: {target_ext_ids}")
    return item_update


def add_to_dict(
    match: EntityMatchingApiMatch,
    entity_view_id: str,
    target_view_id: str,
) -> StoredMatch:
    """
    Add match to dictionary

    Args:
        match: dictionary with match information
    Returns:
        dictionary with match information
    """
    source = match[KEY_SOURCE]
    if len(match[KEY_MATCHES]) > 0:
        target = match[KEY_MATCHES][0][KEY_TARGET]
        score = match[KEY_MATCHES][0][KEY_SCORE]
        target_name = target[KEY_ORG_NAME]
        target_match_value = target[KEY_NAME]
        target_ext_id = target[KEY_TARGET_EXT_ID]
        # The matching API echoes the source/target dicts we submitted, but fall back to
        # the configured space if a field is dropped.
        target_space = target.get(KEY_TARGET_SPACE)
    else:
        score = 0
        target_name = PLACEHOLDER_NO_MATCH
        target_match_value = PLACEHOLDER_NO_MATCH
        target_ext_id = PLACEHOLDER_NO_MATCH
        target_view_id = PLACEHOLDER_NO_MATCH
        target_space = None
    row: StoredMatch = {
        KEY_MATCH_TYPE: MATCH_TYPE_ENTITY,
        KEY_ENTITY_EXT_ID: source[KEY_ENTITY_EXT_ID],
        KEY_ENTITY_SPACE: source.get(KEY_ENTITY_SPACE),
        KEY_ENTITY_NAME: source[KEY_ORG_NAME],
        KEY_ENTITY_MATCH_VALUE: source[KEY_NAME],
        KEY_ENTITY_VIEW_ID: str(entity_view_id),
        KEY_ENTITY_EXISTING_TARGETS: source[KEY_TARGET_LINKS],
        KEY_SCORE: round(score, 2),
        KEY_TARGET_NAME: target_name,
        KEY_TARGET_MATCH_VALUE: target_match_value,
        KEY_TARGET_EXT_ID: target_ext_id,
        KEY_TARGET_SPACE: target_space,
        KEY_TARGET_VIEW_ID: str(target_view_id),
    }
    _copy_scope(source, row)
    return row


def _copy_scope(source: Mapping[str, object], row: StoredMatch) -> None:
    """Copy primary/secondary scope onto a RAW match row when the source carried them."""
    if KEY_SCOPE_PRIMARY in source or KEY_SCOPE_SECONDARY in source:
        row[KEY_SCOPE_PRIMARY] = str(source.get(KEY_SCOPE_PRIMARY) or "")
        row[KEY_SCOPE_SECONDARY] = str(source.get(KEY_SCOPE_SECONDARY) or "")


def raw_row_key(config: Config, match: StoredMatch | Mapping[str, object]) -> str:
    """Row key for a match in the good/bad RAW tables.

    An external ID is unique per space only, so with several entity spaces configured the
    space has to be part of the key or one copy silently overwrites the other. A project
    with a single space keeps the bare external ID it has always been keyed on.
    """
    external_id = str(match[KEY_ENTITY_EXT_ID])
    if len(config.data.entity_view.instance_spaces) < 2:
        return external_id
    return f"{match.get(KEY_ENTITY_SPACE) or ''}:{external_id}"


def write_mapping_to_raw(
    client: CogniteClient,
    config: Config,
    raw_uploader: "RawUploadQueue",
    good_matches: list[StoredMatch],
    bad_matches: list[StoredMatch],
    logger: CogniteFunctionLogger,
) -> None:
    """
    Write matching results to RAW DB

    Rows are written as they are found, without emptying the tables first: a run
    collects one predict job while others are still queued, and their staged matches
    live in the same good table. Clearing before a full re-run is submit's job.

    Args:
        client: Instance of CogniteClient
        config: Instance of ContextConfig
        raw_uploader : Instance of RawUploadQueue
        good_matches: list of good matches
        bad_matches: list of bad matches
    """

    raw_db = config.parameters.raw_db
    raw_table_ctx_bad = config.parameters.raw_table_ctx_bad
    raw_table_ctx_good = config.parameters.raw_table_ctx_good

    try:
        create_table(client, raw_db, raw_table_ctx_bad)
        create_table(client, raw_db, raw_table_ctx_good)

        for match in good_matches:
            raw_uploader.add_to_upload_queue(
                raw_db,
                raw_table_ctx_good,
                Row(raw_row_key(config, match), match),  # type: ignore[arg-type]
            )
            logger.debug(f"Added matched entity: {match[KEY_ENTITY_EXT_ID]} to {raw_db}/{raw_table_ctx_good}")

        for not_match in bad_matches:
            raw_uploader.add_to_upload_queue(
                raw_db,
                raw_table_ctx_bad,
                Row(raw_row_key(config, not_match), not_match),  # type: ignore[arg-type]
            )
            logger.debug(f"Added NOT matched entity: {not_match[KEY_ENTITY_EXT_ID]} to {raw_db}/{raw_table_ctx_bad}")

        # Upload any remaining RAW cols in queue
        raw_uploader.upload()
    except CogniteAPIError as e:
        logger.error(f"Failed to write mapping to RAW DB: {e}")
        raise RuntimeError("Failed to write mapping to RAW DB") from e


def _raise_unless_already_exists(error: CogniteAPIError) -> None:
    """Swallow the error a re-run gets for a database or table it already created.

    RAW answers that with `400`, not the `409` a conflict would suggest, and words it
    differently per resource - "Databases with the following names already exists" but
    "Tables already created" - so the status is what can be relied on. A name RAW will
    not take answers `400` as well, and fails loudly on the first row written to it.
    Everything that says the run cannot proceed - `401`, `403`, `5xx` - is re-raised.
    """
    if error.code != HTTP_STATUS_BAD_REQUEST:
        raise error


def create_table(client: CogniteClient, raw_db: str, tbl: str) -> None:
    """Create the RAW database and table unless a previous run already did."""
    try:
        client.raw.databases.create(raw_db)
    except CogniteAPIError as e:
        _raise_unless_already_exists(e)

    try:
        client.raw.tables.create(raw_db, tbl)
    except CogniteAPIError as e:
        _raise_unless_already_exists(e)
