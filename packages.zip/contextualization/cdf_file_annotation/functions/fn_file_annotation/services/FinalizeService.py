import abc
import time
from typing import Literal, cast

from cognite.client import CogniteClient
from cognite.client.data_classes.data_modeling import (
    Node,
    NodeApply,
    NodeId,
    NodeOrEdgeData,
)
from cognite.client.exceptions import CogniteAPIError
from services.ApplyService import IApplyService
from services.ConfigService import Config, ViewPropertyConfig
from services.LoggerService import CogniteFunctionLogger
from services.RetrieveService import DiagramDetectJobPoll, IRetrieveService, JobPollStatus
from utils.DataStructures import (
    AnnotationStatus,
    BatchOfNodes,
    PerformanceTracker,
    annotation_clock,
    node_tags,
    replace_tag,
    tags_apply,
)
from utils.QueryTimeout import QueryTimeoutRetry, is_query_timeout


def _poll_completed(job: tuple[int, str] | None, poll: DiagramDetectJobPoll | None) -> bool:
    """True when this job was not launched, or its detect job has completed."""
    return job is None or (poll is not None and poll.status == JobPollStatus.COMPLETED)


def claimed_jobs_message(regular_job_id: int | None, pattern_job_id: int | None, claimed_files: int) -> str:
    """Summary of the jobs just claimed. Job tokens are not included."""
    return f"Retrieved regular job {regular_job_id}, pattern job {pattern_job_id} and claimed {claimed_files} files"


class AbstractFinalizeService(abc.ABC):
    """
    Orchestrates the file annotation finalize process.
    This service retrieves the results of the diagram detect jobs from the launch function and then applies annotations to the file.
    Additionally, it captures the file and asset annotations into separate RAW tables.
    """

    def __init__(
        self,
        client: CogniteClient,
        config: Config,
        logger: CogniteFunctionLogger,
        tracker: PerformanceTracker,
        retrieve_service: IRetrieveService,
        apply_service: IApplyService,
    ):
        self.client: CogniteClient = client
        self.config: Config = config
        self.logger: CogniteFunctionLogger = logger
        self.tracker: PerformanceTracker = tracker
        self.retrieve_service: IRetrieveService = retrieve_service
        self.apply_service: IApplyService = apply_service

    @abc.abstractmethod
    def run(self) -> str | None:
        pass


class GeneralFinalizeService(AbstractFinalizeService):
    """
    Implementation of the FinalizeService.
    """

    def __init__(
        self,
        client: CogniteClient,
        config: Config,
        logger: CogniteFunctionLogger,
        tracker: PerformanceTracker,
        retrieve_service: IRetrieveService,
        apply_service: IApplyService,
        function_call_info: dict,
    ):
        super().__init__(
            client,
            config,
            logger,
            tracker,
            retrieve_service,
            apply_service,
        )

        self.annotation_state_view: ViewPropertyConfig = config.data_model_views.annotation_state_view
        self.file_view: ViewPropertyConfig = config.data_model_views.file_view
        self.page_range: int = config.launch_function.annotation_service.page_range
        self.max_retries: int = config.finalize_function.max_retry_attempts
        self.clean_old_annotations: bool = config.finalize_function.clean_old_annotations
        self.query_timeout = QueryTimeoutRetry(logger)
        self.function_id: int | None = function_call_info.get("function_id")
        self.call_id: int | None = function_call_info.get("call_id")

    def run(self) -> Literal["Done"] | None:
        """
        Main execution loop for finalizing diagram detection jobs.

        Retrieves completed jobs, fetches their results, processes annotations for each file,
        and updates annotation state instances. Handles multi-page files by tracking progress
        and requeueing files with remaining pages.

        Args:
            None

        Returns:
            "Done" if no jobs available, None if processing should continue.

        Raises:
            CogniteAPIError: Various API errors are handled gracefully (version conflicts,
                           timeouts, etc.).
        """
        self.logger.info("Starting Finalize Function", section="START")
        try:
            regular_job, pattern_mode_job, file_to_state_map = self.retrieve_service.get_job_id()
            if (not regular_job and not pattern_mode_job) or not file_to_state_map:
                self.logger.info("No diagram detect jobs found", section="END")
                return "Done"
            self.logger.info(
                claimed_jobs_message(
                    regular_job[0] if regular_job else None,
                    pattern_mode_job[0] if pattern_mode_job else None,
                    len(file_to_state_map),
                )
            )
        except CogniteAPIError as e:
            if e.code == 400 and e.message == "A version conflict caused the ingest to fail.":
                self.logger.info(
                    message="Retrieved job that has already been claimed. Grabbing another job.",
                    section="END",
                )
                return None
            elif is_query_timeout(e):
                self.query_timeout.wait(e)
                return None
            else:
                raise e
        self.query_timeout.reset()

        try:
            self._finalize_job(regular_job, pattern_mode_job, file_to_state_map)
        except Exception:
            # Re-raised after releasing, so the next run reads the finished detect jobs instead of waiting 12 hours.
            self.logger.info(f"Finalize failed: handing {len(file_to_state_map)} claimed files back to Processing")
            self._update_batch_state(
                batch=BatchOfNodes(nodes=list(file_to_state_map.values())),
                status=AnnotationStatus.PROCESSING,
            )
            raise
        return None

    def _finalize_job(
        self,
        regular_job: tuple[int, str] | None,
        pattern_mode_job: tuple[int, str] | None,
        file_to_state_map: dict[NodeId, Node],
    ) -> None:
        """
        Reads the results of the claimed detect jobs and applies them to their files and annotation states.

        Args:
            regular_job: Regular diagram detect job ID and token, if any.
            pattern_mode_job: Pattern mode diagram detect job ID and token, if any.
            file_to_state_map: The claimed annotation state node of each file in the jobs.

        Returns:
            None
        """
        regular_poll: DiagramDetectJobPoll | None = None
        pattern_poll: DiagramDetectJobPoll | None = None
        try:
            if regular_job is not None:
                self.logger.info("(Regular) Retrieving diagram detect job results", "START")
                regular_poll = self.retrieve_service.get_diagram_detect_job_result(*regular_job)
            if pattern_mode_job is not None:
                self.logger.info("(Pattern) Retrieving diagram detect job results")
                pattern_poll = self.retrieve_service.get_diagram_detect_job_result(*pattern_mode_job)
        except CogniteAPIError as e:
            self.logger.error(
                message=f"Unfinalizing {len(file_to_state_map.keys())} files. Encountered an error.",
                error=e,
                section="BOTH",
            )
            self._update_batch_state(
                batch=BatchOfNodes(nodes=list(file_to_state_map.values())),
                status=AnnotationStatus.RETRY,
                failed=True,
            )
            return None

        polls = [poll for poll in (regular_poll, pattern_poll) if poll is not None]
        regular_job_id = None if regular_job is None else regular_job[0]
        pattern_job_id = None if pattern_mode_job is None else pattern_mode_job[0]
        if any(poll.status == JobPollStatus.FAILED for poll in polls):
            self.logger.info(
                message=(
                    f"Detect job failed for {len(file_to_state_map)} files "
                    f"(regular job {regular_job_id}, pattern job {pattern_job_id}). "
                    "Marking them AnnotationFailed."
                ),
                section="BOTH",
            )
            self._mark_claimed_files_failed(file_to_state_map)
            return None

        jobs_complete = _poll_completed(regular_job, regular_poll) and _poll_completed(pattern_mode_job, pattern_poll)

        if not jobs_complete:
            self.logger.info(
                message=(
                    f"Unfinalizing {len(file_to_state_map)} files - "
                    f"regular job {regular_job_id} and/or pattern job {pattern_job_id} not complete"
                ),
                section="BOTH",
            )
            self._update_batch_state(
                batch=BatchOfNodes(nodes=list(file_to_state_map.values())),
                status=AnnotationStatus.PROCESSING,
            )
            self.logger.info(message="Sleeping for 30 seconds")
            time.sleep(30)
            return None

        job_results = regular_poll.results if regular_poll is not None else None
        pattern_mode_job_results = pattern_poll.results if pattern_poll is not None else None
        self.logger.info(
            (f"Jobs complete (regular={regular_job_id}, pattern={pattern_job_id}). Applying all annotations."),
            section="END",
        )
        self._log_detect_job_summary("regular", job_results)
        self._log_detect_job_summary("pattern", pattern_mode_job_results)

        regular_items = job_results["items"] if job_results is not None else []
        merged_results = {
            (item["fileInstanceId"]["space"], item["fileInstanceId"]["externalId"]): {"regular": item}
            for item in regular_items
        }
        if pattern_mode_job_results:
            for item in pattern_mode_job_results["items"]:
                key = (
                    item["fileInstanceId"]["space"],
                    item["fileInstanceId"]["externalId"],
                )
                if key in merged_results:
                    merged_results[key]["pattern"] = item
                else:
                    merged_results[key] = {"pattern": item}

        count_retry, count_failed, count_success = 0, 0, 0
        annotation_state_node_applies: list[NodeApply] = []
        file_node_applies: list[NodeApply] = []
        files_by_id = self._files_by_id([NodeId(space, external_id) for space, external_id in merged_results])

        for (space, external_id), results in merged_results.items():
            file_id = NodeId(space, external_id)
            file_node = files_by_id.get(file_id)
            if file_node is None:
                continue

            annotation_state_node = file_to_state_map[file_id]
            state_properties = (annotation_state_node.properties or {}).get(
                self.annotation_state_view.as_view_id()
            ) or {}
            current_attempt = cast(int, state_properties.get("attemptCount") or 0)
            next_attempt = current_attempt + 1

            try:
                self.logger.info(f"Processing file {file_id}:")
                annotation_msg, pattern_msg = self.apply_service.process_and_apply_annotations_for_file(
                    file_node,
                    results.get("regular"),
                    results.get("pattern"),
                    self.clean_old_annotations
                    and (annotation_state_node.properties or {})
                    .get(self.annotation_state_view.as_view_id(), {})
                    .get("annotatedPageCount")
                    is None,
                )
                self.logger.info(f"\t- {annotation_msg}")
                self.logger.info(f"\t- {pattern_msg}")

                # Logic to handle multi-page files
                page_count = results.get("regular", {}).get("pageCount", 1)
                annotated_pages = self._check_all_pages_annotated(annotation_state_node, page_count)

                if annotated_pages == page_count:
                    tags = node_tags(file_node, self.file_view.as_view_id())
                    if "AnnotationInProcess" in tags:
                        tags = replace_tag(tags, "AnnotationInProcess", "Annotated")
                    elif "Annotated" not in tags:
                        self.logger.warning(
                            f"File {file_id.external_id} was processed, but 'AnnotationInProcess' tag was not found."
                        )
                    file_node_applies.append(tags_apply(file_node, self.file_view.as_view_id(), tags))
                    job_node_to_update = self._process_annotation_state(
                        annotation_state_node,
                        AnnotationStatus.ANNOTATED,
                        next_attempt,
                        annotated_pages,
                        page_count,
                        annotation_msg,
                        pattern_msg,
                    )
                    count_success += 1
                else:
                    job_node_to_update = self._process_annotation_state(
                        annotation_state_node,
                        AnnotationStatus.NEW,
                        current_attempt,
                        annotated_pages,
                        page_count,
                        "Processed page batch, more pages remaining",
                        pattern_msg,
                    )
                    count_success += 1  # Still a success for this batch

            except (CogniteAPIError, ValueError, RuntimeError) as e:
                self.logger.error(f"Failed to process annotations for file {file_id}", error=e)
                if next_attempt >= self.max_retries:
                    tags = node_tags(file_node, self.file_view.as_view_id())
                    if "AnnotationInProcess" in tags:
                        tags = replace_tag(tags, "AnnotationInProcess", "AnnotationFailed")
                    elif "AnnotationFailed" not in tags:
                        self.logger.warning(
                            f"File {file_id.external_id} failed processing, but 'AnnotationInProcess' tag was not found."
                        )
                    file_node_applies.append(tags_apply(file_node, self.file_view.as_view_id(), tags))
                    job_node_to_update = self._process_annotation_state(
                        annotation_state_node,
                        AnnotationStatus.FAILED,
                        next_attempt,
                        annotation_message=str(e),
                        pattern_mode_message=str(e),
                    )
                    count_failed += 1
                else:
                    job_node_to_update = self._process_annotation_state(
                        annotation_state_node,
                        AnnotationStatus.RETRY,
                        next_attempt,
                        annotation_message=str(e),
                        pattern_mode_message=str(e),
                    )
                    count_retry += 1

            annotation_state_node_applies.append(job_node_to_update)

        # Batch update the state nodes at the end
        if annotation_state_node_applies or file_node_applies:
            self.logger.info(
                f"Updating {len(annotation_state_node_applies)} annotation state instances",
                section="START",
            )
            try:
                self.apply_service.update_instances(list_node_apply=(annotation_state_node_applies + file_node_applies))
                self.logger.info(
                    f"\t- {count_success} set to Annotated/New\n\t- {count_retry} set to Retry\n\t- {count_failed} set to Failed"
                )
            except CogniteAPIError as e:
                self.logger.error(
                    "Error during batch update of annotation states",
                    error=e,
                    section="END",
                )
                raise

        self.tracker.add_files(success=count_success, failed=(count_failed + count_retry))
        return None

    def _process_annotation_state(
        self,
        node: Node,
        status: str,
        attempt_count: int,
        annotated_page_count: int | None = None,
        page_count: int | None = None,
        annotation_message: str | None = None,
        pattern_mode_message: str | None = None,
    ) -> NodeApply:
        """
        Creates a NodeApply to update an annotation state instance with processing results.

        Updates status, attempt count, timestamps, and page tracking for multi-page files.
        The annotatedPageCount and pageCount properties are updated based on progress through
        the file's pages.

        Args:
            node: The annotation state node to update.
            status: New annotation status (ANNOTATED, FAILED, NEW, RETRY).
            attempt_count: Current attempt count for this file.
            annotated_page_count: Number of pages successfully annotated so far.
            page_count: Total number of pages in the file.
            annotation_message: Message describing regular annotation results.
            pattern_mode_message: Message describing pattern mode results.

        Returns:
            NodeApply object ready to be applied to update the annotation state.

        NOTE: Create a node apply from the node passed into the function.
        The annotatedPageCount and pageCount properties won't be set if this is the first time the job has been run for the specific node.
        Thus, we set it here and include logic to handle the scneario where it is set.
        NOTE: Always want to use the latest page count from the diagram detect results
        e.g.) let page_range = 50
            - If the pdf has less than 50 pages, say 3 pages, then...
                - annotationStatus property will get set to 'complete'
                - annotatedPageCount and pageCount properties will be set to 3.
            - Elif the pdf has more than 50 pages, say 80, then...
                - annotationStatus property will get set to 'new'
                - annotatedPageCount set to 50
                - pageCount set to 80
                - attemptCount doesn't get incremented
            - If an error occurs, the annotated_page_count and page_count won't be passed
                - Don't want to touch the pageCount and annotatedPageCount properties in this scenario
        """
        update_properties = {
            "annotationStatus": status,
            **annotation_clock(),
            "annotationMessage": annotation_message,
            "patternModeMessage": pattern_mode_message,
            "attemptCount": attempt_count,
            "finalizeFunctionId": self.function_id,
            "finalizeFunctionCallId": self.call_id,
        }
        if annotated_page_count and page_count:
            update_properties["annotatedPageCount"] = annotated_page_count
            update_properties["pageCount"] = page_count

        node_apply = NodeApply(
            space=node.space,
            external_id=node.external_id,
            existing_version=None,
            sources=[
                NodeOrEdgeData(
                    source=self.annotation_state_view.as_view_id(),
                    properties=update_properties,
                )
            ],
        )

        return node_apply

    def _check_all_pages_annotated(self, node: Node, page_count: int) -> int:
        """
        Calculates how many pages have been annotated after this batch completes.

        Handles progressive annotation of multi-page files by tracking which pages have been
        processed based on the configured page_range batch size.

        Args:
            node: The annotation state node being processed.
            page_count: Total number of pages in the file from diagram detect results.

        Returns:
            Number of pages annotated after this batch (includes previous batches).

        NOTE: The annotatedPageCount and pageCount properties won't be set if this is the first time the job has been run for the specific node.
        - if annotated_page_count is not set (first run):
            - if page_range >= to the page count:
                - annotated_page_count = page_count b/c all of the pages were passed into the FileReference during LaunchService
            - else:
                - annotated_page_count = page_range b/c there are more pages to annotate
        - else the annotation_page_count property is set:
            - if (annotated_page_count + page_range) >= page_count:
                -  annotated_page_count = page_count b/c all of the pages were passed into the FileReference during LaunchService
            else:
                - annotated_page_count = self.page_range + annotated_page_count b/c there are more pages to annotate
        """
        annotated_page_count: int | None = cast(
            int,
            ((node.properties or {}).get(self.annotation_state_view.as_view_id()) or {}).get("annotatedPageCount"),
        )

        if not annotated_page_count:
            annotated_page_count = page_count if self.page_range >= page_count else self.page_range
            self.logger.info(f"Annotated pages 1-to-{annotated_page_count} out of {page_count} total pages", "END")
        else:
            start_page = annotated_page_count + 1
            if (annotated_page_count + self.page_range) >= page_count:
                annotated_page_count = page_count
            else:
                annotated_page_count += self.page_range
            self.logger.info(
                f"Annotated pages {start_page}-to-{annotated_page_count} out of {page_count} total pages", "END"
            )

        return annotated_page_count

    def _log_detect_job_summary(self, label: str, job_results: dict | None) -> None:
        """Log INFO/DEBUG summary of a diagram detect job payload."""
        if job_results is None:
            self.logger.info(f"Detect job summary ({label}): no results payload")
            return

        status_count = job_results.get("statusCount") or {}
        items = job_results.get("items") or []
        ok_annotations = 0
        failed_items = 0
        error_preview: list[str] = []
        for item in items:
            error = item.get("errorMessage")
            if error:
                failed_items += 1
                file_id = item.get("fileInstanceId") or {}
                error_preview.append(f"{file_id.get('space')}/{file_id.get('externalId')}: {error}")
            else:
                ok_annotations += len(item.get("annotations") or [])

        self.logger.info(
            f"Detect job summary ({label}): statusCount={status_count}, "
            f"items={len(items)}, failedItems={failed_items}, "
            f"annotationHits={ok_annotations}"
        )
        if error_preview:
            preview = error_preview[:10]
            self.logger.info(
                f"Detect job errors ({label}) — showing {len(preview)}/{len(error_preview)}:\n"
                + "\n".join(f"  • {line}" for line in preview)
            )
        if self.logger.log_level == "DEBUG":
            for item in items:
                file_id = item.get("fileInstanceId") or {}
                anns = item.get("annotations") or []
                texts = [a.get("text") for a in anns[:40]]
                self.logger.debug(
                    f"Detect item ({label}) {file_id.get('space')}/{file_id.get('externalId')}: "
                    f"{len(anns)} annotation(s)"
                    + (f" texts={texts}" if texts else "")
                    + (" ..." if len(anns) > 40 else "")
                    + (f" error={item.get('errorMessage')!r}" if item.get("errorMessage") else "")
                )

    def _files_by_id(self, file_ids: list[NodeId]) -> dict[NodeId, Node]:
        """Read every file in one retrieve. A single-node response is accepted for callers that still return one."""
        if not file_ids:
            return {}
        retrieved = self.client.data_modeling.instances.retrieve_nodes(
            nodes=file_ids, sources=self.file_view.as_view_id()
        )
        if retrieved is None:
            return {}
        if isinstance(retrieved, Node):
            return {retrieved.as_id(): retrieved}
        return {node.as_id(): node for node in retrieved}

    def _mark_claimed_files_failed(self, file_to_state_map: dict[NodeId, Node]) -> None:
        """Terminal detect failure: AnnotationFailed on the state and on the file tag, with both job ids cleared."""
        self._update_batch_state(
            batch=BatchOfNodes(nodes=list(file_to_state_map.values())),
            status=AnnotationStatus.FAILED,
            failed=True,
        )
        file_applies: list[NodeApply] = []
        for file_id, file_node in self._files_by_id(list(file_to_state_map)).items():
            tags = node_tags(file_node, self.file_view.as_view_id())
            if "AnnotationInProcess" in tags:
                tags = replace_tag(tags, "AnnotationInProcess", "AnnotationFailed")
            elif "AnnotationFailed" not in tags:
                self.logger.warning(
                    f"File {file_id.external_id} failed processing, but 'AnnotationInProcess' tag was not found."
                )
            file_applies.append(tags_apply(file_node, self.file_view.as_view_id(), tags))
        if file_applies:
            self.apply_service.update_instances(list_node_apply=file_applies)

    def _update_batch_state(
        self,
        batch: BatchOfNodes,
        status: AnnotationStatus,
        failed: bool = False,
    ):
        """
        Updates annotation state instances in bulk, typically for error scenarios.

        Used when jobs are incomplete or failed to reset job IDs and update status for
        retry or re-queuing.

        Args:
            batch: BatchOfNodes containing annotation state nodes to update.
            status: New annotation status to set for all nodes.
            failed: Whether this is a failure scenario (clears job IDs if True).

        Returns:
            None
        """
        if len(batch.nodes) == 0:
            return None

        self.logger.info(message=f"Updating {len(batch.nodes)} annotation state instances")
        if failed:
            node_update_properties = {
                "annotationStatus": status,
                **annotation_clock(),
                "diagramDetectJobId": None,
                "patternModeJobId": None,
            }
        elif status == AnnotationStatus.PROCESSING:
            state_properties = (batch.nodes[0].properties or {}).get(self.annotation_state_view.as_view_id(), {})
            raw_time = state_properties.get("sourceUpdatedTime")
            node_update_properties = {
                "annotationStatus": status,
                **annotation_clock(raw_time if isinstance(raw_time, str) else None),
            }
        else:
            node_update_properties = {
                "annotationStatus": status,
                **annotation_clock(),
            }
        batch.update_node_properties(
            new_properties=node_update_properties,
            view_id=self.annotation_state_view.as_view_id(),
        )
        try:
            self.apply_service.update_instances(list_node_apply=batch.apply)
            self.logger.info(f"- set annotation status to {status}")
        except CogniteAPIError as e:
            self.logger.error(
                "Ran into the following error. Trying again in 30 seconds",
                error=e,
                section="END",
            )
            time.sleep(30)
            self.apply_service.update_instances(list_node_apply=batch.apply)
            self.logger.info(f"- set annotation status to {status}")
