import os
from pathlib import Path

from cognite.client import ClientConfig, CogniteClient
from cognite.client.credentials import OAuthClientCredentials
from services.AnnotationService import GeneralAnnotationService
from services.ApplyService import GeneralApplyService
from services.ConfigService import Config, load_config_parameters
from services.DataModelService import GeneralDataModelService
from services.EntityCacheService import GeneralCacheService
from services.EntitySearchService import EntitySearchService
from services.LoggerService import CogniteFunctionLogger
from services.PipelineService import GeneralPipelineService
from services.PromoteCacheService import CacheService as PromoteCacheService
from services.RetrieveService import GeneralRetrieveService
from utils.DataStructures import EnvConfig


def get_env_variables() -> EnvConfig:
    """Read CDF credentials from the environment. Used by local runs, not the CDF Functions runtime."""
    from dotenv import load_dotenv

    print("Loading environment variables from .env...")

    project_path = (Path(__file__).parent / ".env").resolve()
    print(f"project_path is set to: {project_path}")

    load_dotenv()

    required_envvars = (
        "CDF_PROJECT",
        "CDF_CLUSTER",
        "IDP_TENANT_ID",
        "IDP_CLIENT_ID",
        "IDP_CLIENT_SECRET",
    )

    missing = [envvar for envvar in required_envvars if envvar not in os.environ]
    if missing:
        raise ValueError(f"Missing one or more env.vars: {missing}")

    return EnvConfig(
        cdf_project=os.environ["CDF_PROJECT"],
        cdf_cluster=os.environ["CDF_CLUSTER"],
        tenant_id=os.environ["IDP_TENANT_ID"],
        client_id=os.environ["IDP_CLIENT_ID"],
        client_secret=os.environ["IDP_CLIENT_SECRET"],
    )


def create_client(env_config: EnvConfig, debug: bool = False):
    SCOPES = [f"https://{env_config.cdf_cluster}.cognitedata.com/.default"]
    TOKEN_URL = f"https://login.microsoftonline.com/{env_config.tenant_id}/oauth2/v2.0/token"
    creds = OAuthClientCredentials(
        token_url=TOKEN_URL,
        client_id=env_config.client_id,
        client_secret=env_config.client_secret,
        scopes=SCOPES,
    )
    cnf = ClientConfig(
        client_name="DEV_Working",
        project=env_config.cdf_project,
        base_url=f"https://{env_config.cdf_cluster}.cognitedata.com",  # NOTE: base_url might need to be adjusted if on PSAAS or Private Link
        credentials=creds,
        debug=debug,
    )
    client = CogniteClient(cnf)
    return client


def create_config_service(
    function_data: dict[str, object], client: CogniteClient | None = None
) -> tuple[Config, CogniteClient]:
    if client is None:
        env_config = get_env_variables()
        client = create_client(env_config)
    config = load_config_parameters(client=client, function_data=function_data)
    return config, client


def _valid_log_level(log_level: str) -> str:
    level = log_level.upper()
    return level if level in {"DEBUG", "INFO", "WARNING", "ERROR"} else "INFO"


def create_logger_service(log_level: str, filepath: str | None = None) -> CogniteFunctionLogger:
    return CogniteFunctionLogger(
        log_level=_valid_log_level(log_level),
        write=filepath is not None,
        filepath=filepath,
    )


def create_write_logger_service(log_level: str, filepath: str) -> CogniteFunctionLogger:
    return CogniteFunctionLogger(log_level=_valid_log_level(log_level), write=True, filepath=filepath)


def create_general_data_model_service(
    config: Config,
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    data_set_id: int | None = None,
    entity_read_deadline: float | None = None,
) -> GeneralDataModelService:
    return GeneralDataModelService(
        config=config,
        client=client,
        logger=logger,
        data_set_id=data_set_id,
        entity_read_deadline=entity_read_deadline,
    )


def get_pipeline_data_set_id(client: CogniteClient, pipeline_ext_id: str) -> int | None:
    """The data set of the extraction pipeline, which the files the function writes are put in."""
    pipeline = client.extraction_pipelines.retrieve(external_id=pipeline_ext_id)
    return pipeline.data_set_id if pipeline else None


def create_general_entity_cache_service(
    config: Config, client: CogniteClient, logger: CogniteFunctionLogger
) -> GeneralCacheService:
    return GeneralCacheService(config=config, client=client, logger=logger)


def create_general_annotation_service(
    config: Config, client: CogniteClient, logger: CogniteFunctionLogger
) -> GeneralAnnotationService:
    return GeneralAnnotationService(config=config, client=client, logger=logger)


def create_general_retrieve_service(
    client: CogniteClient, config: Config, logger: CogniteFunctionLogger
) -> GeneralRetrieveService:
    return GeneralRetrieveService(client, config, logger)


def create_general_apply_service(
    client: CogniteClient, config: Config, logger: CogniteFunctionLogger
) -> GeneralApplyService:
    return GeneralApplyService(client, config, logger)


def create_entity_search_service(
    config: Config, client: CogniteClient, logger: CogniteFunctionLogger
) -> EntitySearchService:
    return EntitySearchService(config=config, client=client, logger=logger)


def create_promote_cache_service(
    config: Config,
    client: CogniteClient,
    logger: CogniteFunctionLogger,
    entity_search_service: EntitySearchService,
) -> PromoteCacheService:
    return PromoteCacheService(
        config=config,
        client=client,
        logger=logger,
        normalize_fn=entity_search_service.normalize,
    )


def create_general_pipeline_service(client: CogniteClient, pipeline_ext_id: str) -> GeneralPipelineService:
    return GeneralPipelineService(pipeline_ext_id, client)
